# IDP-CMI Technical Design V1.0 — 工程交付包

基线日期：2026-10-15。状态：Engineering/Security/DBA Review Draft。

## 交付结构

- `IDP_CMI_Technical_Design_V1.0.md`：架构、DB 模型、权限、上下文编译、生命周期、独立集成和测试门槛。
- `IDP_CMI_Technical_Design_V1.0.html`：离线独立阅读、目录导航、代码/图示。
- `sql/001_canonical.sql`：15 个 canonical 核心表与基础完整性约束（参考 DDL）。
- `sql/002_rls.sql`：事务局部租户上下文和 FORCE RLS 政策草案。
- `sql/003_projections_optional.sql`：按需启用 FTS/pgvector 派生投影，**不是 S0 强依赖**。
- `sql/transaction_recipes.md`：CAS、撤权、Outbox、删除、投影一致性。
- `api/cmi.openapi.yaml`：Core Spec V1 契约快照（待实现）。
- `api/contract_delta.md`：HTTP/请求和投影票据工程语义。
- `contracts/schemas/*.json`, `contracts/examples/*.json`：Core Spec V1 六项正式结构示例拷贝。
- `algorithms/context_compiler_reference.py`：不含真实权限判断的 deterministic token packing 参考。
- `tests/test_compiler_reference.py`：覆盖 packing 基本行为的 Python unittest。
- `tests/core_acceptance_matrix.csv`：复用上一阶段 40 项核心契约验收矩阵。
- `tests/postgres_integration_plan.md`：20 项待运行的真实数据库、RLS、并发和恢复联调清单。
- `tests/validate_package.py`：静态资源、YAML、JSON Schema、DDL 清单和示例检查；**不模拟 PostgreSQL 运行测试**。

## 快速校验

```bash
cd IDP_CMI_Technical_Design_V1.0
python -m unittest discover -s tests -p 'test_*.py' -v
python tests/validate_package.py
```

需要 Python 3.11+，`PyYAML`、`jsonschema` 依赖用于静态校验；无网络请求。实际部署必须配备 PostgreSQL 集成/并发测试、IAM/PDP 联调、安全审核和运行压测。

**请注意**：本包不是可启动的 CMI 服务，不提供预配置真实数据库凭据；DDL 未经真实数据库执行与迁移验证。文档中接口路径是设计合同，不表示已发布商用 API。
