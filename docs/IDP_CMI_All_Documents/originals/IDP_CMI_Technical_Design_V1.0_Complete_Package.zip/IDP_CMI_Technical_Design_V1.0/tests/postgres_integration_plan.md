# IDP-CMI PostgreSQL Integration Test Plan V1 (NOT YET EXECUTED)

Requires a disposable real PostgreSQL >=16 instance, a migration owner and an application role `cmi_app` with `LOGIN,NOBYPASSRLS`, no superuser, no table ownership. Execute as CI automation only after DBA verifies GRANT/roles. Never test with production tenant data.

| ID | Setup/action | Expected acceptance |
|---|---|---|
| DB-01 | Install 001 as migration owner, role+GRANT, apply 002 | 15 canonical tables, FORCE RLS, no app owner privileges |
| DB-02 | `BEGIN` without cmi.tenant_id, select source_record | Returns no tenant rows; invalid GUC errors fail closed |
| DB-03 | Set trusted tenant A with `set_config(...,true)` in transaction; insert A | A rows visible in same transaction only |
| DB-04 | Insert B while bound to tenant A | Rejected by RLS WITH CHECK |
| DB-05 | Pool connection reuse after A commit, no SET LOCAL, query | No tenant rows returned; no leaked A scope |
| DB-06 | Tenant B bound, query known A ID | Not found / no content leakage; resource enumeration shield at API |
| DB-07 | Memory A + Source A; try source link tenant B | Composite FK rejects unauthorized cross-tenant reference |
| DB-08 | Two concurrent CAS writers same expected_revision | Exactly one success, one 412; no two current winners |
| DB-09 | Same key/hash vs same key/different hash | Idempotent replay vs 409 conflict |
| DB-10 | Create Source then memory revisions/outbox and rollback | No canonical revision/outbox partial writes |
| DB-11 | Kill projection worker after engine write before ACK | Replay idempotent; no duplicate visible projection |
| DB-12 | Process old revision projection after revoke block | No revoked memory output or restored active state |
| DB-13 | Revoke source with active dependent memory and old bundle | Immediately deny memory and bundle; no wait for ANN cleanup |
| DB-14 | Erasure Phase A before asynchronous purge | All APIs deny content while job remains in progress |
| DB-15 | Erasure verified after supported purge | No claim, content URI, embeddings, cached text or readable bundle retained; minimal tombstone only |
| DB-16 | Restore stale backup + replay purge denylist before traffic | Deleted records remain inaccessible; not directly open traffic |
| DB-17 | RLS against outbox, receipt and audit tables | Same tenant isolation as canonical tables |
| DB-18 | Denied PDP with tenant matching | DB tenant RLS does not override app-level deny |
| DB-19 | English FTS and Chinese text cases | Document Chinese limitations and quality separately, don't claim equal retrieval quality |
| DB-20 | pgvector selected profile: exact vs filtered HNSW | Record recall@k, P95 and tenant profile with cost; do not assume ANN provides ACL |

**Operational tests**: migrations rerun/downgrade strategy, WAL/backup recovery, per-tenant data size, memory growth, outbox dead-letter, data residency, KMS availability, OpenTelemetry non-PII logging.

Results evidence per test: `test_id`, build/git commit, PostgreSQL+extension version, role grants, normalized sanitized input, observed output, trace_id, owner, timestamp, failure ticket. Gate failure blocks production release, not documentation review.
