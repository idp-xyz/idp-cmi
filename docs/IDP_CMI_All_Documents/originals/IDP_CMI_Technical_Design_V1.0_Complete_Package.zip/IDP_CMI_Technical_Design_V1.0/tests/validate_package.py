"""Static package validator ONLY. Does not execute PostgreSQL or test real authorization."""
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]
issues=[]
for name in ['IDP_CMI_Technical_Design_V1.0.md','sql/001_canonical.sql','sql/002_rls.sql',
             'sql/003_projections_optional.sql','api/cmi.openapi.yaml',
             'algorithms/context_compiler_reference.py','README.md']:
    if not (ROOT/name).exists(): issues.append('missing: '+name)

try:
    import yaml
    openapi=yaml.safe_load((ROOT/'api/cmi.openapi.yaml').read_text())
    assert openapi['openapi'].startswith('3.1.')
    assert len(openapi['paths'])>=10
    assert '/cmi/v1/contexts/compile' in openapi['paths']
    for path, ops in openapi['paths'].items():
        for verb, op in ops.items():
            if verb not in ('get','post','patch','delete','put'): continue
            assert op.get('responses'), (path,verb)
            assert op.get('operationId'), (path,verb)
    print('OpenAPI YAML: %d paths; basic structural checks OK' % len(openapi['paths']))
except Exception as e: issues.append('OpenAPI parse/structure: '+repr(e))

try:
    import jsonschema
    maps=[('source-record','source-record'),('memory-record','memory-record'),
          ('context-bundle','context-bundle'),('lifecycle-transition','lifecycle-transition'),
          ('authorization-context','authorization-context'),('erasure-tombstone','erasure-tombstone')]
    for a,b in maps:
        schema=json.loads((ROOT/f'contracts/schemas/{a}.schema.json').read_text())
        example=json.loads((ROOT/f'contracts/examples/{b}.json').read_text())
        jsonschema.Draft202012Validator.check_schema(schema)
        jsonschema.validate(example,schema)
    print('JSON Schema and example: %d verified' % len(maps))
except Exception as e: issues.append('schema/example: '+repr(e))

sql=(ROOT/'sql/001_canonical.sql').read_text()
tables=set(re.findall(r'CREATE TABLE\s+cmi\.(\w+)',sql))
expected={'source_record','source_revision','memory_record','memory_revision','memory_source_link',
'visibility_block','context_bundle','context_bundle_item','privacy_operation',
'erasure_tombstone','idempotency_record','outbox_event','projection_receipt','engine_mapping','audit_event_ref'}
if tables!=expected: issues.append('canonical table mismatch '+str(expected^tables))
else: print('Canonical DDL: 15 required tables present')
rls=(ROOT/'sql/002_rls.sql').read_text()
for table in expected:
    if "'"+table+"'" not in rls: issues.append('RLS coverage missing '+table)
if 'FORCE ROW LEVEL SECURITY' not in rls: issues.append('RLS FORCE absent')
if not issues: print('RLS coverage: 15 core tables declared (static check)')

proj=(ROOT/'sql/003_projections_optional.sql').read_text()
for item in ('memory_fts_projection','memory_embedding_projection'):
    if item not in proj: issues.append('missing projection '+item)

if issues:
    print('FAILED:',*issues,sep='\n - ');sys.exit(1)
print('PASS: package static checks; PostgreSQL execution tests NOT run')
