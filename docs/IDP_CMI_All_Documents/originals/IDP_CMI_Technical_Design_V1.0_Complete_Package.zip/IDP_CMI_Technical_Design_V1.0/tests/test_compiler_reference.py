import unittest
from algorithms.context_compiler_reference import Candidate, InsufficientBudget, compile_authorized_candidates

def c(name, toks, score=1, required=False):
    return Candidate(name,1,('src-'+name,), 'observation', 'example '+name,toks,score,1,1,required)

class CompilerTests(unittest.TestCase):
    def run_compiler(self, candidates, hard=100):
        return compile_authorized_candidates(candidates,hard_limit_tokens=hard,
            reserved_output_tokens=20,reserved_system_tokens=10,provenance_overhead_tokens=5)
    def test_deterministic_selection(self):
        cs=[c('b',50,2),c('a',20,1)]
        self.assertEqual(self.run_compiler(cs)['selected'][0]['memory_id'],'b')
        self.assertEqual(self.run_compiler(cs),self.run_compiler(cs))
    def test_over_budget_is_omitted_not_truncated(self):
        r=self.run_compiler([c('big',80),c('small',15,0.5)])
        self.assertEqual([x['memory_id'] for x in r['selected']],['small'])
        self.assertEqual(r['omitted_refs'],[('big',1)])
    def test_required_cannot_silently_drop(self):
        with self.assertRaises(InsufficientBudget): self.run_compiler([c('required',70,required=True)])
    def test_dedup_revision(self):
        self.assertEqual(len(self.run_compiler([c('x',5),c('x',5)])['selected']),1)
    def test_provenance_required(self):
        invalid=Candidate('a',1,tuple(),'observation','x',1,1,1,1)
        with self.assertRaises(ValueError): self.run_compiler([invalid])
    def test_cannot_exceed_budget(self):
        r=self.run_compiler([c(str(i),12,1/i) for i in range(1,9)])
        self.assertLessEqual(r['used_context_tokens_estimated'],r['context_budget'])
if __name__ == '__main__': unittest.main()
