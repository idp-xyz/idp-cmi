# API Implementation Notes & Contract Delta V1

`api/cmi.openapi.yaml` is a snapshot of Core Spec V1, not a claim that implementation exists. It uses OpenAPI 3.1.0, within OpenAPI 3.1.x standards.

## Status / idempotency / timing

- `POST /sources/ingest`: `201` means source canonical transaction committed, `202` means request accepted for asynchronous processing (no source commit claimed); match `Idempotency-Key` scoped to principal.
- `POST /memories/propose`: always candidate on creation. `approved/authority/tenant` are computed by trusted server policies, not incoming model text.
- `POST /memories/{id}/transitions`: `expected_revision` is mandatory; `412` on revision mismatch, `409` on conflicting idempotency request.
- `POST /memories/search`: `min_projection_watermark` is an opaque per-write ticket; specify required projection generation, wait bounded duration, else `409 PROJECTION_LAG`.
- `POST /contexts/compile`: `201` means a bounded manifest was committed, not a business execution. Must include trust/provenance warnings and up-to-date policy reference.
- `POST /contexts/{id}/validate`: must check prior Bundle ttl/policy versions/source+memory visibility; invalid is a successful validation response with `valid=false`, not necessarily HTTP error.
- `POST /privacy/erasure-requests`: `202` = accepted; operation state must progress to verified or exception; never mistake accepted for completed.
- `GET /health/live`: does not touch HOST/EER/engines. `ready` checks critical enabled CMI dependencies.

## Response fields to finalize before SDK generation

- `consistency`: eventual vs bounded required ticket.
- `projection_watermark`: opaque `{event_id,generation,projection}` token; never call it committed monotonic sequence.
- `source_refs`: `source_id + immutable revision + content span` where authorized.
- `policy_version` and revalidation result must be returned to HOST.
- `as_of_valid`, `known_at`, `temporal_mode`: document time semantics and missing history due to erasure.
- `errors`: `INSUFFICIENT_CONTEXT_BUDGET` should be added to structured 422 responses.

**Open API change control**: detailed serialization changes must produce Core Spec V1.x (if backward compatible) or V2 (if not), with contract tests and SDK diff. Do not silently make ADR diagrams normative API contracts.
