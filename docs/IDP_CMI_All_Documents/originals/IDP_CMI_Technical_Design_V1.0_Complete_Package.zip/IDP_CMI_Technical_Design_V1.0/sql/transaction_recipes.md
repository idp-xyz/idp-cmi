# Transaction Recipes / 事务边界 (DESIGN)

> 在取得运行数据库后需要做隔离级别、RLS、死锁、并发和断线实测。以下是行为要求和 SQL 示意，不应粘贴成生产存储过程。

## 1. Tenant transaction bootstrap

- HTTP Gateway 在校验 JWT `iss/aud/exp` 与授权委派链后，映射得到 `tenant_id`、`principal_ref`、`purpose`；客户端自填租户无效。
- 从 `cmi_app` 非 owner、NOBYPASSRLS 连接池取连接；每个**请求事务**运行 `BEGIN; SELECT set_config('cmi.tenant_id', :trusted_tenant, true);`；进行 SQL + PDP 校验后 `COMMIT/ROLLBACK`。`true` 意味事务局部配置。连接复用的下一事务没有租户值。
- `cmi.tenant_id` 是由可信进程建立的 DB 租户维度防线，**不是独立认证凭据**。一旦 SQL 注入使其可被改写，RLS 就不再是充分的强租户隔离。严格客户租户可独立数据库/角色。
- 普通服务不使用 OWNER 或 BYPASSRLS；RLS 本身也不检查 object/purpose 权限，应用每个读写命令必须再由 PDP 判定。

## 2. Memory proposal + CAS transition

1. `(tenant, principal, operation, idempotency_key)` 查已有请求；同键异 hash → `409`，同键同 hash → 恢复原结果。
2. `BEGIN`, `SET LOCAL tenant`, 策略前置校验（含来源范围、分类、有效期、审批）。
3. `SELECT ... FROM cmi.memory_record WHERE (tenant_id,memory_id)=... FOR UPDATE`；`current_revision <> expected_revision` → `ROLLBACK` + `412`。
4. 追加 `memory_revision`；插入 `memory_source_link` 固定来源版本；更新 `memory_record.current_revision/status`。所有来源须同租户且无 `visibility_block`。
5. 若 `target_status` 不可普通访问，同一事务插入/更新 `visibility_block` 并将相关 `context_bundle.status='invalidated'`；status 回到可见时必须显式移除有效 block（需 policy owner 准许）。
6. 同事务插入 `outbox_event`、`audit_event_ref`、`idempotency_record`；提交后才允许确认成功。**注意** IDP EER 的业务写指令不允许由此路径生成。
7. 提供 opaque projection ticket（当前 outbox `event_id`），客户端传入以等待本次特定投影 ACK；不能把数据库自增序列当已提交顺序。

## 3. Source revoke / dependency barrier

1. 在**同一 DB 事务**更新 Source 的 `status='revoked'` 和 source visibility block。
2. 找到 `memory_source_link` 依赖集合，更新记忆 block；通过 `context_bundle_item` 找到 Bundle，标记 invalidated / block。
3. 事务中生成 outbox 清索引消息；随后异步下发所有 engine/cache/object store 净化请求。
4. 若受影响集合太大，不能先返回 200 再慢慢建屏蔽：先写租户级/source 级 denial barrier；查询路径检查祖先来源 block，后台扇出完成后再决定是否清除广域 barrier。未经压测不可采用全量行锁循环。
5. 必须处理新的候选创建与撤销操作并发：写侧提交之前做源 status 再检查；依赖登记与源撤销在同一锁序中，或以 serializable+重试实现线性屏蔽。

## 4. Outbox processing / projection generation

同一租户的 worker：事务读取 `status=pending` 或租约过期消息、按 `next_attempt_at` 排序，`FOR UPDATE SKIP LOCKED LIMIT n` 领取 lease；提交事务后调用外部引擎；再次事务以 `event_id + generation + projection_name` 写 `projection_receipt`，再改变 outbox status。失败按退避重试，超过阈值进入 dead_letter。不要对本业务事件进行可重复产生业务效果的处理（只构建投影）。

`SKIP LOCKED` 仅适用于队列消费者，不应用于普通数据检索。不同 aggregate 事件可能乱序：投影 worker 必须使用记录 revision 和当前 canonical status，旧版本事件不得覆盖新版本。在切换 generation 前校验全量投影记录数、删除名单和 ACL。

## 5. Erasure (two-phase)

- Phase A（同步安全屏蔽）：验证擦除授权并创建 `privacy_operation`；建立 visibility block，标记所有依赖 Bundle 失效；先确认未授权读路径 0 结果。若有合法保留例外，标记 `exception` 并记录合规依据。
- Phase B（异步物理净化）：对象、source/memory revision、FTS、embedding、graph、engine bank、派生摘要、Bundle blob、缓存等按依赖顺序清理，每步可重试且带最小证据。必要时重建引擎 generation。
- Phase C（完成验证）：全域扫描 + 第三方 ACK + 恢复演练策略确认；在允许的情况下删除包含内容的 canonical 行、保留不含明文最小 tombstone；`privacy_operation.status='verified'`。保留例外时不能标记 verified。
- 备份/PITR 不能假定实时覆盖全部删除；恢复后先重放已确认擦除屏蔽/删除清单，再开放服务。

## 6. Read consistency

- 查询先用 Registry/visibility/ACL 做候选允许范围，再 FTS/engine/vector，返回前强制 re-check Registry + Source 依赖 + PDP；Bundle 消费前再 `validate`。
- `min_projection_watermark` V1 解释为**opaque event ticket / generation token**，不是单调全局事务序号；如果所需投影没有 receipt → 等待有限时间或返回 `409 PROJECTION_LAG`，绝不假装“没有匹配记忆”。
- 需要权威最新订单或 EER Execution State 时，应使用其 SoR/Execution API；CMI 的历史事实不能替代实际检查。
