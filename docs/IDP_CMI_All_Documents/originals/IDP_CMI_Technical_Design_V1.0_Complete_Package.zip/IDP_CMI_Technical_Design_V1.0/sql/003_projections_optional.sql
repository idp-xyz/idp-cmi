-- TECH-003 optional derived projections. NO vector model assumed in canonical core.
-- Apply after explicit embedding profile is selected and extension licensing checked.
BEGIN;
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE cmi.memory_fts_projection (
 tenant_id uuid NOT NULL,
 memory_id uuid NOT NULL,
 revision integer NOT NULL,
 generation text NOT NULL,
 language text NOT NULL,
 search_text text NOT NULL,
 search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, search_text)) STORED,
 updated_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,memory_id,revision,generation)
);
CREATE INDEX memory_fts_gin ON cmi.memory_fts_projection USING gin(search_vector);
CREATE INDEX memory_fts_scope ON cmi.memory_fts_projection(tenant_id,generation);
CREATE TABLE cmi.memory_embedding_projection (
 tenant_id uuid NOT NULL,
 memory_id uuid NOT NULL,
 revision integer NOT NULL,
 generation text NOT NULL,
 embedding_model_id text NOT NULL,
 embedding_dim integer NOT NULL CHECK(embedding_dim>0),
 embedding vector NOT NULL,
 indexed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
 PRIMARY KEY(tenant_id,memory_id,revision,generation,embedding_model_id),
 CHECK(vector_dims(embedding)=embedding_dim)
);
CREATE INDEX memory_embedding_scope ON cmi.memory_embedding_projection(tenant_id,generation,embedding_model_id);
-- DO NOT deploy one global ANN index blindly: select dimensions/profile and isolation by measured workload.
-- Example ONLY for an approved 1024-dimension embedding model:
-- CREATE INDEX ... ON cmi.memory_embedding_projection USING hnsw
-- ((embedding::vector(1024)) vector_cosine_ops)
-- WHERE embedding_model_id='approved-model' AND embedding_dim=1024;
ALTER TABLE cmi.memory_fts_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE cmi.memory_fts_projection FORCE ROW LEVEL SECURITY;
CREATE POLICY fts_tenant_policy ON cmi.memory_fts_projection FOR ALL TO cmi_app
 USING(tenant_id=NULLIF(current_setting('cmi.tenant_id',true),'')::uuid)
 WITH CHECK(tenant_id=NULLIF(current_setting('cmi.tenant_id',true),'')::uuid);
ALTER TABLE cmi.memory_embedding_projection ENABLE ROW LEVEL SECURITY;
ALTER TABLE cmi.memory_embedding_projection FORCE ROW LEVEL SECURITY;
CREATE POLICY embedding_tenant_policy ON cmi.memory_embedding_projection FOR ALL TO cmi_app
 USING(tenant_id=NULLIF(current_setting('cmi.tenant_id',true),'')::uuid)
 WITH CHECK(tenant_id=NULLIF(current_setting('cmi.tenant_id',true),'')::uuid);
COMMIT;
