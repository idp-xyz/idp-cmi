"""IDP-CMI TECH-001: deterministic packing REFERENCE ONLY, not a production PDP/tokenizer.

Input candidates MUST already be obtained via server-owned authn+PDP prefilter.
A production integration MUST perform a fresh PDP/registry/source visibility check
AFTER retrieval and BEFORE serializing output. Do not expose this function directly
as an authenticated public endpoint.
"""
from dataclasses import dataclass
from typing import Sequence

@dataclass(frozen=True)
class Candidate:
    memory_id: str
    revision: int
    source_ids: tuple[str, ...]
    assertion_kind: str
    content: str
    estimated_tokens: int
    retrieval_score: float
    authority_fit: float
    temporal_fit: float
    is_required: bool = False
    requires_live_revalidation: bool = False

class InsufficientBudget(ValueError):
    pass


def compile_authorized_candidates(
    candidates: Sequence[Candidate],
    *, hard_limit_tokens: int,
    reserved_output_tokens: int,
    reserved_system_tokens: int,
    provenance_overhead_tokens: int,
) -> dict:
    """Deterministic fit / never truncate text. No authorization or LLM call here."""
    for n in (hard_limit_tokens, reserved_output_tokens, reserved_system_tokens, provenance_overhead_tokens):
        if n < 0:
            raise ValueError('budgets must not be negative')
    available = hard_limit_tokens - reserved_output_tokens - reserved_system_tokens
    if available < 0:
        raise InsufficientBudget('required model/output reserve exceeds budget')
    if any(c.estimated_tokens < 0 or not c.source_ids or not c.memory_id for c in candidates):
        raise ValueError('candidates must have provenance and non-negative token estimate')
    # Canonical ID + revision dedup; stable tie-breaker by ID. Authorization is NOT a score.
    keyed = {}
    for c in candidates:
        k = (c.memory_id, c.revision)
        if k not in keyed or c.retrieval_score > keyed[k].retrieval_score:
            keyed[k] = c
    normalized = list(keyed.values())
    def ranking(c):
        return (-(c.retrieval_score * c.authority_fit * c.temporal_fit), c.memory_id, c.revision)
    normalized.sort(key=lambda c: (not c.is_required, *ranking(c)))
    required_cost = sum(c.estimated_tokens + provenance_overhead_tokens for c in normalized if c.is_required)
    if required_cost > available:
        raise InsufficientBudget('required grounded context cannot fit; caller must change task/budget')
    accepted, omitted, used = [], [], 0
    for c in normalized:
        cost = c.estimated_tokens + provenance_overhead_tokens
        if used + cost <= available:
            accepted.append(c)
            used += cost
        else:
            omitted.append((c.memory_id, c.revision))
    return {
        'selected': [
            {'memory_id': c.memory_id, 'revision': c.revision,
             'source_ids': list(c.source_ids), 'assertion_kind': c.assertion_kind,
             'content': c.content, 'requires_live_revalidation': c.requires_live_revalidation}
            for c in accepted
        ],
        'omitted_refs': omitted,
        'used_context_tokens_estimated': used,
        'context_budget': available,
        'budget_exhausted': bool(omitted),
        'exact_count': False,
    }
