-- DBA controlled, run with CREATE ROLE privilege. Set password separately via secret manager.
-- NO PASSWORD IS EMBEDDED. Normal service connection must use cmi_app, not schema owner.
DO $plpgsql$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cmi_app') THEN
    CREATE ROLE cmi_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOBYPASSRLS;
  END IF;
END $plpgsql$;
-- Provision a distinct migration account, with schema ownership, using operator IAM.
-- Review role flags in your deployment: cmi_app must remain NOBYPASSRLS/non-owner.
