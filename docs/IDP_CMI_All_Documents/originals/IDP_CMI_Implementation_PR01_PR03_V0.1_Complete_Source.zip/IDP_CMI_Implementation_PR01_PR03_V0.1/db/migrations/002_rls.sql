-- IDP-CMI TECH-002 RLS, DESIGN EXAMPLE.
-- REQUIREMENT: roles cmi_owner (NOLOGIN, table owner), cmi_app (LOGIN, NOBYPASSRLS)
-- provisioned by privileged deployment/IAM automation, not by this migration.
-- Must NEVER use superuser, BYPASSRLS or owner credentials for the normal application pool.
-- The trusted API establishes cmi.tenant_id via SET LOCAL after verifying caller token.
-- This policy is tenant defense-in-depth ONLY; PDP resource/purpose checks remain mandatory.
BEGIN;
DO $block$
DECLARE t text;
BEGIN
 FOR t IN
  SELECT unnest(ARRAY[
   'source_record','source_revision','memory_record','memory_revision','memory_source_link',
   'visibility_block','context_bundle','context_bundle_item','privacy_operation',
   'erasure_tombstone','idempotency_record','outbox_event','projection_receipt',
   'engine_mapping','audit_event_ref'])
 LOOP
  EXECUTE format('ALTER TABLE cmi.%I ENABLE ROW LEVEL SECURITY', t);
  EXECUTE format('ALTER TABLE cmi.%I FORCE ROW LEVEL SECURITY', t);
  EXECUTE format(
   'CREATE POLICY %I ON cmi.%I FOR ALL TO cmi_app '
   || 'USING (tenant_id = NULLIF(current_setting(''cmi.tenant_id'', true), '''')::uuid) '
   || 'WITH CHECK (tenant_id = NULLIF(current_setting(''cmi.tenant_id'', true), '''')::uuid)',
    t || '_tenant_policy',t
  );
 END LOOP;
END
$block$;
-- Apply minimum table/column GRANT privileges to cmi_app in separate role migration.
-- Never grant direct SQL access to clients, untrusted jobs or engine containers.
COMMIT;
