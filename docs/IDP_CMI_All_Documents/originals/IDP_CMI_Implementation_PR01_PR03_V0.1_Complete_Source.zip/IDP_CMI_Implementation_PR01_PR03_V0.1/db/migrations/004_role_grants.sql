-- DBA-reviewed minimum grants for application role. Run as owner/authorized migration role.
BEGIN;
GRANT USAGE ON SCHEMA cmi TO cmi_app;
GRANT SELECT, INSERT, UPDATE ON cmi.source_record,cmi.memory_record,cmi.context_bundle,
 cmi.privacy_operation,cmi.idempotency_record,cmi.outbox_event TO cmi_app;
GRANT SELECT, INSERT ON cmi.source_revision,cmi.memory_revision,cmi.memory_source_link,
 cmi.visibility_block,cmi.context_bundle_item,cmi.erasure_tombstone,
 cmi.projection_receipt,cmi.engine_mapping,cmi.audit_event_ref TO cmi_app;
-- No DELETE grant to the normal API principal; erasure runs via separately governed role.
COMMIT;
