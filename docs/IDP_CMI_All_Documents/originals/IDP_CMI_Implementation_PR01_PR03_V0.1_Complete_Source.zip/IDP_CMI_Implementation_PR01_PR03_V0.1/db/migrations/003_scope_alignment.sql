-- Core Spec V1 scope enum must be consistent with public Scope API.
BEGIN;
ALTER TABLE cmi.memory_record DROP CONSTRAINT IF EXISTS memory_record_scope_type_check;
ALTER TABLE cmi.memory_record ADD CONSTRAINT memory_record_scope_type_check
 CHECK (scope_type IN ('tenant','organization','user','business_object','project','team'));
COMMIT;
