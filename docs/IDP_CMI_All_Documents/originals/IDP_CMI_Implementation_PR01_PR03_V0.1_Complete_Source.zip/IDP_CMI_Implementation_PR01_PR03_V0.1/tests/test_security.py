import time
from uuid import uuid4
import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from idp_cmi.config import Settings
from idp_cmi.security import Actor, Policy, decode_actor
from idp_cmi.models import Scope
from idp_cmi.domain import DomainError

@pytest.fixture
def signed_token(tmp_path):
    key = rsa.generate_private_key(public_exponent=65537,key_size=2048)
    pub = key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    file = tmp_path / 'public.pem'; file.write_bytes(pub)
    tenant = str(uuid4())
    settings = Settings(jwt_public_key_file=str(file),jwt_issuer='urn:test:issuer',jwt_audience='idp-cmi',policy_mode='signed_claims_poc')
    claims = {'iss': 'urn:test:issuer','aud':'idp-cmi','sub':'operator', 'tenant_id':tenant,
       'exp':int(time.time())+300, 'iat':int(time.time()),'cmi_actions':['memory:read'],
       'cmi_purposes':['exception_triage'],'cmi_scopes':['project:parcel-v1']}
    return jwt.encode(claims,key,algorithm='RS256'),settings

def test_signed_token_verification(signed_token):
    token,settings=signed_token
    actor=decode_actor('Bearer '+token,settings)
    assert actor.principal=='operator'
    Policy(settings).allow(actor,'memory:read',Scope(type='project',id='parcel-v1'),'exception_triage')

def test_policy_fail_closed(signed_token):
    token,s=signed_token
    actor=decode_actor('Bearer '+token,s)
    with pytest.raises(DomainError):
        Policy(Settings(policy_mode='deny')).allow(actor,'memory:read')
    with pytest.raises(DomainError) as e:
        Policy(s).allow(actor,'memory:read',Scope(type='project',id='project-x'),'exception_triage')
    assert e.value.status==403

def test_token_not_forged(signed_token):
    token,s=signed_token
    with pytest.raises(DomainError):
        decode_actor('Bearer '+token+'x',s)
    with pytest.raises(DomainError):
        decode_actor(None,s)
