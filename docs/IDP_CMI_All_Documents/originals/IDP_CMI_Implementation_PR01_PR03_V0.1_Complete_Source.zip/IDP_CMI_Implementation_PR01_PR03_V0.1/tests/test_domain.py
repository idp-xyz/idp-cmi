import pytest
from idp_cmi.domain import DomainError, assert_transition, ensure_revision, classification_max
from idp_cmi.models import ProposeRequest, TransitionRequest, IngestRequest
from idp_cmi.storage import request_hash


def test_transition_valid():
    assert_transition('candidate','active','approved:123')
    assert_transition('active','revoked',None)

@pytest.mark.parametrize('old,new', [('revoked','active'),('active','candidate'),('candidate','disputed'),('expired','active')])
def test_transition_invalid(old,new):
    with pytest.raises(DomainError) as e:
        assert_transition(old,new,'approved:123')
    assert e.value.code == 'INVALID_TRANSITION'

def test_approval_required():
    with pytest.raises(DomainError) as e:
        assert_transition('candidate','active',None)
    assert e.value.code == 'APPROVAL_REQUIRED'

def test_cas():
    with pytest.raises(DomainError) as e:
        ensure_revision(1,2)
    assert e.value.status == 412

def test_classification():
    assert classification_max(['internal','restricted','public']) == 'restricted'

def test_cannot_supply_authoritative_fields():
    with pytest.raises(Exception):
        ProposeRequest.model_validate({
            'scope':{'type':'tenant','id':'some-tenant'}, 'subject_ref':'x',
            'kind':'episodic','claim_text':'hello', 'language':'en','source_refs':[],
            'status':'active','source_trust':'authoritative_domain','tenant_id':'forged'
        })

def test_hash_stable():
    a = TransitionRequest(expected_revision=1,target_status='revoked',reason_code='privacy')
    assert request_hash(a) == request_hash(a)
    assert request_hash(a) != request_hash(TransitionRequest(expected_revision=1,target_status='expired',reason_code='privacy'))
