from uuid import uuid4
from fastapi.testclient import TestClient
from idp_cmi.app import create_app
from idp_cmi.config import Settings
from idp_cmi.security import Actor

class FakeDB:
    def ready(self): return True
    def ingest(self, actor, payload, key): return {'source_id':str(uuid4()), 'revision':1,'status':'available'}
    def propose(self, actor, payload, key): return {'memory_id':str(uuid4()), 'revision':1,'status':'candidate'}
    def transition(self, actor, memory_id, payload, key): return {'memory_id':str(memory_id),'revision':2,'status':payload.target_status}
    def find(self, actor, memory_id): return None
    def search(self, actor, query, scope, top_k): return []

def setup():
    a=create_app(Settings(policy_mode='signed_claims_poc'),FakeDB())
    routes=a.routes
    dep = next(route.dependant.dependencies[0].call for route in routes if getattr(route,'path',None)=='/cmi/v1/sources/ingest')
    tenant=uuid4()
    actor=Actor(tenant,'operator',frozenset({'source:ingest','memory:propose','memory:read','memory:approve','memory:transition'}),
                 frozenset({'memory','triage'}),frozenset({f'tenant:{tenant}','project:parcel-v1'}))
    a.dependency_overrides[dep]=lambda:actor
    return TestClient(a),actor

def test_independent_liveness():
    client,_=setup()
    r=client.get('/cmi/v1/health/live')
    assert r.status_code==200 and r.json()['status']=='alive'
    r=client.get('/cmi/v1/health/ready')
    assert r.status_code==200 and r.json()['production_ready'] is False

def test_unconfigured_denies_readiness():
    client=TestClient(create_app(Settings()))
    assert client.get('/cmi/v1/health/live').status_code==200
    assert client.get('/cmi/v1/health/ready').status_code==503

def test_reject_untrusted_fields():
    client,_=setup()
    payload={'scope':{'type':'project','id':'parcel-v1'},'subject_ref':'parcel:PK100',
            'kind':'episodic','claim_text':'history','language':'en',
            'source_refs':[{'source_id':str(uuid4()),'source_revision':1}],
            'tenant_id':str(uuid4()), 'status':'active'}
    r=client.post('/cmi/v1/memories/propose',json=payload,headers={'Idempotency-Key':'p1'})
    assert r.status_code==422

def test_ingest_does_not_accept_arbitrary_uri():
    client,_=setup()
    payload={'source_system':'parcel','source_object_key':'ev1','source_revision':1,
            'source_type':'event','captured_at':'2026-10-15T00:00:00Z',
            'content_hash':'sha256:'+'a'*64,'content_location':'https://private.example/secret'}
    r=client.post('/cmi/v1/sources/ingest',json=payload,headers={'Idempotency-Key':'s1'})
    assert r.status_code==400 and r.json()['error']['code']=='SOURCE_LOCATION_DENIED'
    assert 'X-Request-ID' in r.headers

def test_ingest_valid_shape_and_propose_candidate():
    client,_=setup()
    payload={'source_system':'parcel','source_object_key':'ev1','source_revision':1,
            'source_type':'event','captured_at':'2026-10-15T00:00:00Z',
            'content_hash':'sha256:'+'a'*64,'content_location':'s3://cmi-ingested/case01'}
    r=client.post('/cmi/v1/sources/ingest',json=payload,headers={'Idempotency-Key':'s1'})
    assert r.status_code==201
    proposed={'scope':{'type':'project','id':'parcel-v1'},'subject_ref':'parcel:PK100',
              'kind':'episodic','claim_text':'Historical address exception','language':'en',
              'source_refs':[{'source_id':str(uuid4()),'source_revision':1}]}
    r=client.post('/cmi/v1/memories/propose',json=proposed,headers={'Idempotency-Key':'m1'})
    assert r.status_code==201 and r.json()['status']=='candidate'

def test_scope_denied_on_propose():
    client,_=setup()
    proposed={'scope':{'type':'project','id':'other-customer'},'subject_ref':'parcel:PK100',
              'kind':'episodic','claim_text':'history','language':'en',
              'source_refs':[{'source_id':str(uuid4()),'source_revision':1}]}
    r=client.post('/cmi/v1/memories/propose',json=proposed,headers={'Idempotency-Key':'m1'})
    assert r.status_code==403

def test_memory_read_not_found_no_disclosure():
    client,_=setup()
    r=client.get('/cmi/v1/memories/'+str(uuid4()))
    assert r.status_code==404

def test_reject_missing_idempotency_key():
    client,_=setup()
    payload={'source_system':'parcel','source_object_key':'ev1','source_revision':1,
            'source_type':'event','captured_at':'2026-10-15T00:00:00Z',
            'content_hash':'sha256:'+'a'*64,'content_location':'s3://cmi-ingested/case01'}
    r=client.post('/cmi/v1/sources/ingest',json=payload)
    assert r.status_code==400 and r.json()['error']['code']=='INVALID_IDEMPOTENCY_KEY'

def test_captured_at_must_have_timezone():
    client,_=setup()
    payload={'source_system':'parcel','source_object_key':'ev1','source_revision':1,
            'source_type':'event','captured_at':'2026-10-15T00:00:00',
            'content_hash':'sha256:'+'a'*64,'content_location':'s3://cmi-ingested/case01'}
    assert client.post('/cmi/v1/sources/ingest',json=payload,headers={'Idempotency-Key':'s1'}).status_code==422
