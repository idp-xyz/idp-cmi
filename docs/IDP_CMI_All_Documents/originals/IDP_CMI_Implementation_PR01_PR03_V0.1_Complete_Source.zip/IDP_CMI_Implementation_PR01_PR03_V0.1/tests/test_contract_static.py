from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]

def test_migrations_tenant_and_rls():
    a=(ROOT/'db/migrations/001_canonical.sql').read_text()
    b=(ROOT/'db/migrations/002_rls.sql').read_text()
    c=(ROOT/'db/migrations/003_scope_alignment.sql').read_text()
    assert len(re.findall(r'CREATE TABLE cmi\.',a))==15
    assert 'FORCE ROW LEVEL SECURITY' in b
    assert 'current_setting(' in b
    assert "'business_object'" in c
    assert 'GRANT' in (ROOT/'db/migrations/004_role_grants.sql').read_text()

def test_mutations_have_transactional_outbox_and_cas():
    s=(ROOT/'src/idp_cmi/storage.py').read_text()
    assert 'with self.engine.begin() as conn:' in s
    assert 'FOR UPDATE' in s
    assert 'self._event(' in s
    assert 'source_revision' in s

def test_orphaned_memory_cannot_be_read_when_source_link_is_deleted():
    s=(ROOT/'src/idp_cmi/storage.py').read_text()
    assert s.count('AND EXISTS (SELECT 1 FROM cmi.memory_source_link p') == 2
    assert 'Memory has no remaining source references' in s
