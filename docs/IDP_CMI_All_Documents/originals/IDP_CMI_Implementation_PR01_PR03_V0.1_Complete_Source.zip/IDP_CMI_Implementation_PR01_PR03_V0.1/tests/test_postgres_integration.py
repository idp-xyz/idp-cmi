"""Real PostgreSQL >=16 test. Only executes when CMI_TEST_DATABASE_URL is configured.

CI creates cmi_app and migrations; this test must never target production data.
"""
import os
from datetime import datetime, timezone
from uuid import UUID, uuid4
import pytest
from sqlalchemy import text
from idp_cmi.storage import Database
from idp_cmi.security import Actor
from idp_cmi.models import Scope, IngestRequest, ProposeRequest, SourceRef, TransitionRequest
from idp_cmi.domain import DomainError

DB_URL=os.getenv('CMI_TEST_DATABASE_URL')
pytestmark=pytest.mark.skipif(not DB_URL, reason='requires disposable real PostgreSQL configured by CMI_TEST_DATABASE_URL')

def actor(tenant=None):
    tenant=tenant or uuid4()
    return Actor(tenant,'integration-operator',frozenset({'memory:read','source:ingest'}),
                 frozenset({'memory'}),frozenset({f'tenant:{tenant}','project:parcel-v1'}))

def make_source(obj_key='evt1',rev=1):
    return IngestRequest(source_system='parcel',source_object_key=obj_key,source_revision=rev,
       source_type='event',captured_at=datetime.now(timezone.utc),
       content_hash='sha256:'+'a'*64,content_location='s3://cmi-ingested/test-event')

def make_memory(sid,revision=1):
    return ProposeRequest(scope=Scope(type='project',id='parcel-v1'),
       subject_ref='parcel:PK0179', kind='episodic',claim_text='Shipment address had no house number',
       language='en',source_refs=[SourceRef(source_id=UUID(sid),source_revision=revision)])

def test_db_rls_cas_outbox_revoke_and_revision_staleness():
    db=Database(DB_URL)
    a,b=actor(),actor()
    key=str(uuid4())
    source_v1=make_source(obj_key='parcel-event-'+key)
    s=db.ingest(a,source_v1,key)
    assert s['revision']==1 and s['replayed'] is False
    sr=db.ingest(a,source_v1,key)
    assert sr['source_id']==s['source_id'] and sr['replayed'] is True
    with pytest.raises(DomainError) as conflict:
        db.ingest(a,make_source(obj_key='parcel-event-other-'+key),key)
    assert conflict.value.code=='IDEMPOTENCY_CONFLICT'

    m=db.propose(a,make_memory(s['source_id']),str(uuid4()))
    mid=UUID(m['memory_id'])
    assert db.find(a,mid) is None  # candidates are never published
    activated=db.transition(a,mid,TransitionRequest(expected_revision=1,target_status='active',
                               reason_code='reviewed',approval_ref='approved:reviewer'),str(uuid4()))
    assert activated['revision']==2
    assert db.find(a,mid)['status']=='active'
    assert len(db.search(a,'house',Scope(type='project',id='parcel-v1'),10))==1
    assert db.find(b,mid) is None
    with db.transaction(b) as conn:
        assert conn.scalar(text('SELECT count(*) FROM cmi.source_record WHERE source_id=:sid'),
                           {'sid':s['source_id']})==0
    with pytest.raises(DomainError) as mismatch:
        db.transition(a,mid,TransitionRequest(expected_revision=1,target_status='revoked',
                      reason_code='revoked'),str(uuid4()))
    assert mismatch.value.status==412

    # Current authoritative source revision moves forward; old dependent memory is hidden.
    db.ingest(a,make_source(obj_key='parcel-event-'+key,rev=2),str(uuid4()))
    assert db.find(a,mid) is None
    assert db.search(a,'house',Scope(type='project',id='parcel-v1'),10)==[]

    revoked=db.transition(a,mid,TransitionRequest(expected_revision=2,target_status='revoked',
                          reason_code='revoked'),str(uuid4()))
    assert revoked['status']=='revoked' and revoked['revision']==3
    assert db.find(a,mid) is None
    with db.transaction(a) as conn:
        assert conn.scalar(text('SELECT count(*) FROM cmi.memory_revision WHERE memory_id=:mid'),
                           {'mid':str(mid)})==3
        assert conn.scalar(text('SELECT count(*) FROM cmi.outbox_event WHERE aggregate_id=:mid'),
                           {'mid':str(mid)})==3
        assert conn.scalar(text('SELECT count(*) FROM cmi.visibility_block WHERE resource_id=:mid'),
                           {'mid':str(mid)})==1
    # SET LOCAL never leaks between transactions on pool reuse.
    with db.engine.connect() as conn:
        assert conn.scalar(text('SELECT count(*) FROM cmi.source_record'))==0
    db.engine.dispose()
