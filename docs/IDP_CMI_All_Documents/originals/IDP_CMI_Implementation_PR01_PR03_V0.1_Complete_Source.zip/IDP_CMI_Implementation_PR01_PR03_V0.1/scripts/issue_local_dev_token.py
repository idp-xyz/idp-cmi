#!/usr/bin/env python3
"""Generate temporary local test keypair + JWT; do NOT use in production."""
import argparse
import time
from pathlib import Path
from uuid import uuid4
import jwt
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--tenant',default=str(uuid4()))
    p.add_argument('--key-dir',default='.local-secrets')
    p.add_argument('--project',default='parcel-v1')
    a=p.parse_args()
    path=Path(a.key_dir);path.mkdir(parents=True,exist_ok=True,mode=0o700)
    private=path/'dev_private.pem';public=path/'dev_public.pem'
    if not private.exists() or not public.exists():
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        private.write_bytes(key.private_bytes(serialization.Encoding.PEM,
           serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        private.chmod(0o600)
        public.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,
           serialization.PublicFormat.SubjectPublicKeyInfo))
    key=serialization.load_pem_private_key(private.read_bytes(),password=None)
    now=int(time.time())
    claims={'iss':'urn:local:idp-cmi','aud':'idp-cmi','iat':now,'exp':now+1800,
            'sub':'local-demo-operator','tenant_id':a.tenant,
            'cmi_actions':['source:ingest','memory:propose','memory:approve',
                           'memory:transition','memory:read'],
            'cmi_purposes':['memory','triage'],
            'cmi_scopes':['tenant:'+a.tenant,'project:'+a.project]}
    print('Tenant ID:',a.tenant)
    print('Bearer token (local only, expires in 30m):')
    print(jwt.encode(claims,key,algorithm='RS256'))
if __name__=='__main__': main()
