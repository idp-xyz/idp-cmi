#!/usr/bin/env bash
# Local dev only. Uses PG17 container with temporary test password.
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose up -d postgres
echo 'Waiting for local postgres...'
for i in $(seq 1 30); do
  if docker compose exec -T postgres pg_isready -U postgres -d cmi >/dev/null 2>&1; then break; fi
  sleep 1
done
for p in 000_privileged_bootstrap 001_canonical 002_rls 003_scope_alignment 004_role_grants; do
  echo "Applying $p"
  docker compose exec -T postgres psql -v ON_ERROR_STOP=1 -U postgres -d cmi <"db/migrations/${p}.sql"
done
docker compose exec -T postgres psql -v ON_ERROR_STOP=1 -U postgres -d cmi \
  -c "ALTER ROLE cmi_app PASSWORD 'local_app_dev_only'"
echo 'Local integration URL: postgresql+psycopg://cmi_app:local_app_dev_only@127.0.0.1:55432/cmi'
echo 'The API must additionally configure JWT verification and explicit PoC policy mode.'
