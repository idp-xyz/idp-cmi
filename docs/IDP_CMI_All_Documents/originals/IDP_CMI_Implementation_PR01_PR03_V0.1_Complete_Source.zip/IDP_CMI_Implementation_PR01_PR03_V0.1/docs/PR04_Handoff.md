# PR-04 Handoff — Context Compiler S0 (proposal, not implemented)

## Objective
Build policy-governed, reproducible ContextBundle assembly over **canonical** memory records without importing external memory engines. Keep HOST and EER optional.

## Pre-conditions (no exceptions)
1. Execute real PostgreSQL tests in disposable DB.
2. Verify JWT issuer/audience and role permissions under a production-grade PDP.
3. Introduce verified Source ingestion and approved reference verification before production customer data.
4. Finalize implementation/OpenAPI delta decision and migration versioning.

## Candidate implementation work
- `context/compiler.py`: deterministic candidate fetch, mandatory content, tokenizer budget and source provenance.
- `context/manifest.py`: item references and revision hashes; no plaintext to untrusted logs.
- `context/validation.py`: source+memory still active, same policy version, TTL, least privilege scope, revalidation.
- `db/migrations/005_...`: approved bundle store and dependency indexes.
- `api`: `/contexts/compile`, `/contexts/{id}`, `/contexts/{id}/validate`.

## Mandatory tests
- No revoked memory or source passes compilation.
- Source revision update invalidates previously compiled Bundle.
- `ContextBundle` cannot be replayed after access policy changes.
- Hard token limit includes system/output reservation and source citation markup.
- Deterministic packing for identical input and source snapshots.
- No release if tokenizer estimate silently claimed exact.
- Compiler requires no Hindsight, Mem0, EER, HOST or MCP infrastructure to boot.

## Explicit boundary
PR-04 may not edit EER's Verifier or authoritative SoR state. Context assembly never writes business operations.
