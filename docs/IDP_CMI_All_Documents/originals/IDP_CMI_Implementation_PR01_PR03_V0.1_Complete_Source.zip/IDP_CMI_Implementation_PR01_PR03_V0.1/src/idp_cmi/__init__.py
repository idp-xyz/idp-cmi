"""Independent IDP Context & Memory Infrastructure core."""
