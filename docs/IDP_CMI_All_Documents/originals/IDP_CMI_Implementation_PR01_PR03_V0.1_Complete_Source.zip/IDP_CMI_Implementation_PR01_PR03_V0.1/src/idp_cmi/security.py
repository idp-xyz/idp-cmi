"""Verify signed identity; restrictive policy. No trusted identity headers or JWT=none."""
from dataclasses import dataclass
from uuid import UUID
from fastapi import Header
import jwt
from .config import Settings
from .domain import DomainError
from .models import Scope

@dataclass(frozen=True)
class Actor:
    tenant_id: UUID
    principal: str
    actions: frozenset[str]
    purposes: frozenset[str]
    scopes: frozenset[str]


def decode_actor(authorization: str | None, settings: Settings) -> Actor:
    if not authorization or not authorization.startswith('Bearer '):
        raise DomainError('UNAUTHENTICATED', 'Bearer token required', 401)
    if not all([settings.jwt_public_key_file, settings.jwt_issuer, settings.jwt_audience]):
        raise DomainError('AUTH_UNCONFIGURED', 'JWT verifier not configured', 503)
    try:
        with open(settings.jwt_public_key_file, encoding='utf8') as f:
            key = f.read()
        claims = jwt.decode(authorization[7:], key, algorithms=['RS256'],
                            audience=settings.jwt_audience, issuer=settings.jwt_issuer,
                            options={'require': ['sub','exp','iat','iss','aud','tenant_id']},
                            leeway=15)
        if not all(isinstance(claims.get(name), list) and all(isinstance(x, str) for x in claims[name])
                   for name in ('cmi_actions', 'cmi_purposes', 'cmi_scopes')):
            raise ValueError('Invalid claims shape')
        return Actor(
            UUID(str(claims['tenant_id'])), str(claims['sub']),
            frozenset(claims.get('cmi_actions', [])),
            frozenset(claims.get('cmi_purposes', [])),
            frozenset(claims.get('cmi_scopes', [])),
        )
    except (OSError, jwt.PyJWTError, ValueError, KeyError, TypeError):
        raise DomainError('UNAUTHENTICATED', 'Invalid signed access token', 401)

class Policy:
    """Restricted PoC policy. Production requires a real enterprise PDP adapter."""
    def __init__(self, settings: Settings):
        self.settings = settings

    def allow(self, actor: Actor, action: str, scope: Scope | None = None, purpose: str = 'memory') -> None:
        if self.settings.policy_mode != 'signed_claims_poc':
            raise DomainError('POLICY_UNAVAILABLE', 'External PDP is not connected; fail closed', 503)
        if action not in actor.actions or purpose not in actor.purposes:
            raise DomainError('FORBIDDEN', 'Action or purpose not permitted', 403)
        if scope is not None and f'{scope.type}:{scope.id}' not in actor.scopes:
            raise DomainError('FORBIDDEN', 'Resource scope not permitted', 403)
