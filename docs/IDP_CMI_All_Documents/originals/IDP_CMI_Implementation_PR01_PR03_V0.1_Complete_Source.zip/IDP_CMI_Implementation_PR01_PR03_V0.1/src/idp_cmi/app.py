"""PR-01..03 HTTP surface. No HOST, EER, MCP or memory-engine imports."""
from uuid import UUID, uuid4
from fastapi import Depends, FastAPI, Header, Request
from fastapi.responses import JSONResponse
from .config import Settings
from .domain import DomainError
from .models import IngestRequest, ProposeRequest, TransitionRequest, SearchRequest, Scope
from .security import Actor, Policy, decode_actor
from .storage import Database


def create_app(settings: Settings | None = None, db=None) -> FastAPI:
    app = FastAPI(title='IDP-CMI Core', version='0.1.0',
                  description='Independent S0 prototype: PR-01..PR-03 only.')
    app.state.settings = settings or Settings.from_env()
    app.state.db = db
    app.state.policy = Policy(app.state.settings)

    @app.exception_handler(DomainError)
    async def domain_error(request: Request, exc: DomainError):
        return JSONResponse(status_code=exc.status, content={'error': {
            'code': exc.code, 'message': str(exc), 'request_id': request.state.request_id,
            'retryable': exc.status in (503, 429)}})

    @app.middleware('http')
    async def trace(request: Request, call_next):
        request.state.request_id = str(uuid4())
        response = await call_next(request)
        response.headers['X-Request-ID'] = request.state.request_id
        response.headers['Cache-Control'] = 'no-store'
        return response

    def _db():
        if app.state.db is None:
            if not app.state.settings.database_url:
                raise DomainError('DATABASE_UNCONFIGURED','PostgreSQL is not configured',503)
            try:
                app.state.db = Database(app.state.settings.database_url)
            except (ImportError, ValueError) as e:
                raise DomainError('DATABASE_CONFIGURATION_ERROR',str(e),503)
        return app.state.db

    def require_idempotency_key(key: str | None) -> str:
        if not key or len(key) > 200:
            raise DomainError('INVALID_IDEMPOTENCY_KEY', 'Idempotency-Key is required (max 200 chars)', 400)
        return key

    def get_actor(authorization: str | None = Header(default=None)) -> Actor:
        return decode_actor(authorization, app.state.settings)

    @app.get('/cmi/v1/health/live')
    def live():
        return {'status': 'alive', 'service': 'idp-cmi', 'version': '0.1.0'}

    @app.get('/cmi/v1/health/ready')
    def ready():
        # PoC policy mode is explicitly non-production; real PDP adapter is future work.
        if app.state.settings.policy_mode != 'signed_claims_poc':
            raise DomainError('POLICY_UNAVAILABLE','No configured usable PDP',503)
        try:
            if not _db().ready():
                raise DomainError('DATABASE_UNAVAILABLE','PostgreSQL not ready',503)
        except DomainError:
            raise
        except Exception:
            raise DomainError('DATABASE_UNAVAILABLE','PostgreSQL not ready',503)
        return {'status':'ready','policy_mode':'signed_claims_poc', 'production_ready': False}

    @app.post('/cmi/v1/sources/ingest', status_code=201)
    def ingest(payload: IngestRequest, actor: Actor = Depends(get_actor),
               idempotency_key: str | None = Header(default=None)):
        app.state.policy.allow(actor,'source:ingest',Scope(type='tenant',id=str(actor.tenant_id)))
        if not payload.content_location.startswith(app.state.settings.source_location_prefix):
            raise DomainError('SOURCE_LOCATION_DENIED','Source URI prefix not allowlisted',400)
        return _db().ingest(actor,payload,require_idempotency_key(idempotency_key))

    @app.post('/cmi/v1/memories/propose', status_code=201)
    def propose(payload: ProposeRequest, actor: Actor = Depends(get_actor),
                idempotency_key: str | None = Header(default=None)):
        app.state.policy.allow(actor,'memory:propose',payload.scope)
        return _db().propose(actor,payload,require_idempotency_key(idempotency_key))

    @app.post('/cmi/v1/memories/{memory_id}/transitions')
    def transition(memory_id: UUID, payload: TransitionRequest,
                   actor: Actor = Depends(get_actor),
                   idempotency_key: str | None = Header(default=None)):
        action = 'memory:approve' if payload.target_status == 'active' else 'memory:transition'
        app.state.policy.allow(actor,action)
        # Repository also checks bound resource scope *inside* locked database transaction.
        return _db().transition(actor,memory_id,payload,require_idempotency_key(idempotency_key))

    @app.get('/cmi/v1/memories/{memory_id}')
    def get_memory(memory_id: UUID, actor: Actor = Depends(get_actor)):
        app.state.policy.allow(actor,'memory:read')
        row = _db().find(actor,memory_id)
        if not row:
            raise DomainError('NOT_FOUND','Memory does not exist or is not readable',404)
        app.state.policy.allow(actor,'memory:read',Scope(type=row['scope_type'], id=row['scope_ref']))
        return row

    @app.post('/cmi/v1/memories/search')
    def search(payload: SearchRequest, actor: Actor = Depends(get_actor)):
        app.state.policy.allow(actor,'memory:read',payload.scope,payload.purpose)
        return {'items':_db().search(actor,payload.query,payload.scope,payload.top_k),
                'consistency':'canonical', 'index_profile':'postgres_fts_simple_and_substring'}

    return app
