from datetime import datetime
from typing import Literal
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, field_validator

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

class Scope(StrictModel):
    type: Literal['tenant','organization','user','business_object','project','team']
    id: str = Field(min_length=3, max_length=256)

class SourceRef(StrictModel):
    source_id: UUID
    source_revision: int = Field(ge=1)

class IngestRequest(StrictModel):
    source_system: str = Field(min_length=1, max_length=100)
    source_object_key: str = Field(min_length=1, max_length=512)
    source_revision: int = Field(ge=1)
    source_type: Literal['event','document','conversation','api_snapshot','human_attestation']
    captured_at: datetime
    content_hash: str = Field(pattern=r'^sha256:[0-9a-f]{64}$')
    content_location: str = Field(min_length=1, max_length=1024)
    client_request_ref: str | None = None

    @field_validator('captured_at')
    @classmethod
    def require_timezone(cls, v: datetime) -> datetime:
        if v.tzinfo is None or v.utcoffset() is None:
            raise ValueError('captured_at must include timezone')
        return v

class ProposeRequest(StrictModel):
    scope: Scope
    subject_ref: str = Field(min_length=1)
    kind: Literal['working','episodic','semantic','procedural','preference']
    claim_text: str = Field(min_length=1, max_length=10000)
    language: str = Field(min_length=1, max_length=30)
    source_refs: list[SourceRef] = Field(min_length=1, max_length=40)

class TransitionRequest(StrictModel):
    expected_revision: int = Field(ge=1)
    target_status: Literal['candidate','quarantined','active','disputed','superseded','expired','revoked']
    reason_code: str = Field(min_length=3, max_length=128)
    approval_ref: str | None = None

class SearchRequest(StrictModel):
    query: str = Field(min_length=1, max_length=1000)
    scope: Scope
    purpose: str = Field(min_length=1)
    top_k: int = Field(default=10, ge=1, le=100)

class SourceResponse(StrictModel):
    source_id: UUID
    revision: int
    status: str

class MemoryResponse(StrictModel):
    memory_id: UUID
    revision: int
    status: str
    kind: str
    scope: Scope
    subject_ref: str
    claim_text: str | None = None
    source_refs: list[SourceRef] = Field(default_factory=list)
