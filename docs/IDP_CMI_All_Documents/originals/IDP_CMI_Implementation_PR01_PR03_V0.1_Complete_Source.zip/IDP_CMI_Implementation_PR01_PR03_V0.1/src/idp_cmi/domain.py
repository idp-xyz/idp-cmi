"""Pure domain rules, detached from database, vendor engine, and HOST/EER."""
from enum import StrEnum

class MemoryStatus(StrEnum):
    candidate = 'candidate'
    quarantined = 'quarantined'
    active = 'active'
    disputed = 'disputed'
    superseded = 'superseded'
    expired = 'expired'
    revoked = 'revoked'

TRANSITIONS: dict[str, set[str]] = {
    'candidate': {'active', 'quarantined', 'revoked'},
    'quarantined': {'candidate', 'revoked'},
    'active': {'disputed', 'superseded', 'expired', 'revoked'},
    'disputed': {'active', 'revoked'},
    'superseded': {'revoked'},
    'expired': {'revoked'},
    'revoked': set(),
}

class DomainError(Exception):
    def __init__(self, code: str, message: str, status: int = 409):
        super().__init__(message)
        self.code, self.status = code, status


def assert_transition(current: str, target: str, approval_ref: str | None) -> None:
    if target not in TRANSITIONS.get(current, set()):
        raise DomainError('INVALID_TRANSITION', f'{current} -> {target} is not allowed')
    if target == 'active' and not approval_ref:
        raise DomainError('APPROVAL_REQUIRED', 'Activating a memory requires a trusted approval reference', 403)


def ensure_revision(expected: int, actual: int) -> None:
    if expected != actual:
        raise DomainError('REVISION_MISMATCH', 'Expected revision does not match current revision', 412)


def classification_max(values: list[str]) -> str:
    ordering = ['public', 'internal', 'confidential', 'restricted']
    return max(values, key=ordering.index)
