from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    database_url: str = ""
    jwt_public_key_file: str = ""
    jwt_issuer: str = ""
    jwt_audience: str = ""
    policy_mode: str = "deny"  # deny or signed_claims_poc; external enterprise PDP TBD
    policy_version: str = "poc-v0"
    source_location_prefix: str = "s3://cmi-ingested/"

    @classmethod
    def from_env(cls):
        return cls(
            database_url=os.getenv("CMI_DATABASE_URL", ""),
            jwt_public_key_file=os.getenv("CMI_JWT_PUBLIC_KEY_FILE", ""),
            jwt_issuer=os.getenv("CMI_JWT_ISSUER", ""),
            jwt_audience=os.getenv("CMI_JWT_AUDIENCE", ""),
            policy_mode=os.getenv("CMI_POLICY_MODE", "deny"),
            policy_version=os.getenv("CMI_POLICY_VERSION", "poc-v0"),
            source_location_prefix=os.getenv("CMI_SOURCE_LOCATION_PREFIX", "s3://cmi-ingested/"),
        )
