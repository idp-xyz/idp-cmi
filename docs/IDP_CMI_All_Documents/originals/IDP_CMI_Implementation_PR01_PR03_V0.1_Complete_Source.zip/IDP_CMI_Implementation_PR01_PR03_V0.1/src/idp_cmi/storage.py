"""PostgreSQL canonical repository (no Hindsight/EER/HOST dependencies).

All mutating operations use one DB transaction, tenant SET LOCAL, idempotency
reservation, row locking, appended revision, and transactional outbox.
"""
import hashlib
import json
from contextlib import contextmanager
from datetime import datetime
from uuid import UUID, uuid4
from sqlalchemy import create_engine, text
from .domain import DomainError, assert_transition, ensure_revision, classification_max
from .models import IngestRequest, ProposeRequest, TransitionRequest, Scope
from .security import Actor


def request_hash(model) -> str:
    payload = model.model_dump(mode='json', exclude_none=True)
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode()).hexdigest()

class Database:
    def __init__(self, database_url: str):
        if not database_url.startswith('postgresql+psycopg://'):
            raise ValueError('CMI requires PostgreSQL with psycopg; no silent SQLite fallback')
        self.engine = create_engine(database_url, pool_pre_ping=True, pool_size=5, max_overflow=5)

    @contextmanager
    def transaction(self, actor: Actor):
        with self.engine.begin() as conn:
            conn.execute(text('SELECT set_config(:name, :value, true)'),
                         {'name': 'cmi.tenant_id', 'value': str(actor.tenant_id)})
            yield conn

    def ready(self) -> bool:
        with self.engine.connect() as conn:
            return conn.scalar(text('SELECT 1')) == 1

    @staticmethod
    def _idem_begin(conn, actor: Actor, op: str, key: str, hash_value: str):
        # Required key and same-key competing writers serialize on unique constraint.
        if not key or len(key) > 200:
            raise DomainError('INVALID_IDEMPOTENCY_KEY', 'Idempotency-Key required, max 200 characters', 400)
        p = {'t': str(actor.tenant_id), 'p': actor.principal, 'op': op, 'k': key, 'h': hash_value}
        conn.execute(text('''INSERT INTO cmi.idempotency_record
             (tenant_id,principal_ref,operation_type,idempotency_key,request_hash,expires_at)
             VALUES (:t,:p,:op,:k,:h,clock_timestamp() + interval '1 day')
             ON CONFLICT (tenant_id,principal_ref,operation_type,idempotency_key) DO NOTHING'''), p)
        row = conn.execute(text('''SELECT request_hash, result_ref FROM cmi.idempotency_record
             WHERE tenant_id=:t AND principal_ref=:p AND operation_type=:op AND idempotency_key=:k
             FOR UPDATE'''), p).mappings().one()
        if row['request_hash'] != hash_value:
            raise DomainError('IDEMPOTENCY_CONFLICT', 'Same key used with a different request', 409)
        return row['result_ref']

    @staticmethod
    def _idem_commit(conn, actor: Actor, op: str, key: str, result_ref: str):
        conn.execute(text('''UPDATE cmi.idempotency_record SET result_ref=:r, http_status=201
             WHERE tenant_id=:t AND principal_ref=:p AND operation_type=:op AND idempotency_key=:k'''),
             {'t':str(actor.tenant_id),'p':actor.principal,'op':op,'k':key,'r':result_ref})

    @staticmethod
    def _event(conn, actor: Actor, kind: str, obj_id: str, rev: int, event_type: str):
        conn.execute(text('''INSERT INTO cmi.outbox_event
             (tenant_id,aggregate_kind,aggregate_id,aggregate_revision,event_type,event_payload)
             VALUES (:t,:kind,:obj,:rev,:type,CAST(:body AS jsonb))'''),
             {'t':str(actor.tenant_id),'kind':kind,'obj':obj_id,'rev':rev,'type':event_type,
              'body':json.dumps({'ref':obj_id,'revision':rev})})

    def ingest(self, actor: Actor, data: IngestRequest, key: str):
        with self.transaction(actor) as conn:
            replay = self._idem_begin(conn, actor, 'source.ingest', key, request_hash(data))
            if replay:
                _, source_id, revision = replay.split(':')
                return {'source_id': source_id, 'revision': int(revision), 'status': 'available', 'replayed': True}
            obj = conn.execute(text('''SELECT source_id,current_revision,status FROM cmi.source_record
                WHERE tenant_id=:t AND source_system=:s AND source_object_key=:o FOR UPDATE'''),
                {'t':str(actor.tenant_id),'s':data.source_system,'o':data.source_object_key}).mappings().first()
            if obj:
                sid = str(obj['source_id'])
                if obj['status'] != 'available':
                    raise DomainError('SOURCE_BLOCKED', 'Source is not available')
                if data.source_revision != obj['current_revision']+1:
                    raise DomainError('SOURCE_REVISION_CONFLICT', 'Next source revision required', 412)
                conn.execute(text('''UPDATE cmi.source_record SET current_revision=:r,updated_at=clock_timestamp()
                    WHERE tenant_id=:t AND source_id=:id'''),
                    {'t':str(actor.tenant_id),'id':sid,'r':data.source_revision})
            else:
                if data.source_revision != 1:
                    raise DomainError('SOURCE_REVISION_CONFLICT', 'First source revision must equal 1', 412)
                sid = str(uuid4())
                conn.execute(text('''INSERT INTO cmi.source_record
                 (tenant_id,source_id,source_system,source_object_key,source_type,current_revision,
                  classification,source_trust,access_policy_ref,retention_policy_ref)
                 VALUES (:t,:id,:s,:o,:type,1,'internal','external_untrusted','poc:internal','poc:default')'''),
                 {'t':str(actor.tenant_id),'id':sid,'s':data.source_system,'o':data.source_object_key,'type':data.source_type})
            conn.execute(text('''INSERT INTO cmi.source_revision
                 (tenant_id,source_id,revision,upstream_revision_key,content_hash,content_location,captured_at)
                 VALUES (:t,:id,:r,:k,:hash,:loc,:captured)'''),
                 {'t':str(actor.tenant_id),'id':sid,'r':data.source_revision,'k':str(data.source_revision),
                  'hash':data.content_hash,'loc':data.content_location,'captured':data.captured_at})
            # Source revision updates synchronously invalidate dependent compiled bundles.
            conn.execute(text('''UPDATE cmi.context_bundle SET status='invalidated'
                  WHERE tenant_id=:t AND bundle_id IN (
                      SELECT bundle_id FROM cmi.context_bundle_item WHERE tenant_id=:t
                        AND (source_id=:sid OR memory_id IN (
                          SELECT DISTINCT memory_id FROM cmi.memory_source_link
                           WHERE tenant_id=:t AND source_id=:sid)))'''),
                  {'t':str(actor.tenant_id),'sid':sid})
            self._event(conn,actor,'source',sid,data.source_revision,'cmi.source.ingested')
            self._idem_commit(conn,actor,'source.ingest',key,f'source:{sid}:{data.source_revision}')
            return {'source_id':sid,'revision':data.source_revision,'status':'available','replayed':False}

    def propose(self, actor: Actor, data: ProposeRequest, key: str):
        tenant = str(actor.tenant_id)
        with self.transaction(actor) as conn:
            replay = self._idem_begin(conn, actor, 'memory.propose', key, request_hash(data))
            if replay:
                _,mid,rev = replay.split(':')
                return {'memory_id':mid,'revision':int(rev),'status':'candidate','replayed':True}
            if len(set((str(s.source_id),s.source_revision) for s in data.source_refs)) != len(data.source_refs):
                raise DomainError('DUPLICATE_SOURCE_REF','Duplicate source reference',400)
            classes = []
            for s in data.source_refs:
                row = conn.execute(text('''SELECT sr.classification FROM cmi.source_record sr
                    JOIN cmi.source_revision sv ON sv.tenant_id=sr.tenant_id AND sv.source_id=sr.source_id
                     AND sv.revision=:r
                    WHERE sr.current_revision=:r AND sr.tenant_id=:t AND sr.source_id=:sid AND sr.status='available'
                      AND NOT EXISTS(SELECT 1 FROM cmi.visibility_block b WHERE b.tenant_id=sr.tenant_id
                          AND b.resource_kind='source' AND b.resource_id=sr.source_id)'''),
                    {'t':tenant,'sid':str(s.source_id),'r':s.source_revision}).mappings().first()
                if not row:
                    raise DomainError('SOURCE_UNAVAILABLE','Required source is unavailable',409)
                classes.append(row['classification'])
            mid = str(uuid4())
            conn.execute(text('''INSERT INTO cmi.memory_record
              (tenant_id,memory_id,kind,scope_type,scope_ref,subject_ref,classification,
               access_policy_ref,retention_policy_ref)
              VALUES(:t,:mid,:kind,:stype,:sid,:subject,:class,'poc:internal','poc:default')'''),
              {'t':tenant,'mid':mid,'kind':data.kind,'stype':data.scope.type,'sid':data.scope.id,
               'subject':data.subject_ref,'class':classification_max(classes)})
            conn.execute(text('''INSERT INTO cmi.memory_revision
              (tenant_id,memory_id,revision,claim_text,assertion_kind,language,revision_status)
              VALUES (:t,:mid,1,:claim,'derived_claim',:lang,'candidate')'''),
              {'t':tenant,'mid':mid,'claim':data.claim_text,'lang':data.language})
            for source in data.source_refs:
                conn.execute(text('''INSERT INTO cmi.memory_source_link
                  (tenant_id,memory_id,memory_revision,source_id,source_revision)
                  VALUES (:t,:mid,1,:sid,:rev)'''),
                  {'t':tenant,'mid':mid,'sid':str(source.source_id),'rev':source.source_revision})
            self._event(conn,actor,'memory',mid,1,'cmi.memory.candidate')
            self._idem_commit(conn,actor,'memory.propose',key,f'memory:{mid}:1')
            return {'memory_id':mid,'revision':1,'status':'candidate','replayed':False}

    def transition(self, actor: Actor, mid: UUID, data: TransitionRequest, key: str):
        tenant = str(actor.tenant_id)
        with self.transaction(actor) as conn:
            row = conn.execute(text('''SELECT current_revision,status,scope_type,scope_ref FROM cmi.memory_record
               WHERE tenant_id=:t AND memory_id=:mid FOR UPDATE'''),
               {'t':tenant,'mid':str(mid)}).mappings().first()
            if not row:
                raise DomainError('NOT_FOUND','Memory does not exist',404)
            if f"{row['scope_type']}:{row['scope_ref']}" not in actor.scopes:
                raise DomainError('FORBIDDEN','Resource scope not permitted',403)
            transition_hash = hashlib.sha256((str(mid)+':'+request_hash(data)).encode()).hexdigest()
            replay = self._idem_begin(conn,actor,'memory.transition',key,transition_hash)
            if replay:
                _,ref_id,rev,status = replay.split(':')
                return {'memory_id':ref_id,'revision':int(rev),'status':status,'replayed':True}
            ensure_revision(data.expected_revision,row['current_revision'])
            assert_transition(row['status'],data.target_status,data.approval_ref)
            rev = row['current_revision'] + 1
            prev = conn.execute(text('''SELECT claim_text,assertion_kind,language,valid_from,valid_to,
                   confidence,confidence_method,extractor_id,extractor_version,model_profile_ref
                   FROM cmi.memory_revision WHERE tenant_id=:t AND memory_id=:mid AND revision=:r'''),
                   {'t':tenant,'mid':str(mid),'r':row['current_revision']}).mappings().one()
            # Active cannot be generated from a revoked / blocked / inaccessible source.
            refs = conn.execute(text('''SELECT source_id,source_revision FROM cmi.memory_source_link
                  WHERE tenant_id=:t AND memory_id=:mid AND memory_revision=:r'''),
                  {'t':tenant,'mid':str(mid),'r':row['current_revision']}).mappings().all()
            if data.target_status == 'active':
                if not refs:
                    raise DomainError('SOURCE_UNAVAILABLE', 'Memory has no remaining source references', 409)
                for source in refs:
                    permitted = conn.scalar(text('''SELECT 1 FROM cmi.source_record s
                         WHERE s.tenant_id=:t AND s.source_id=:sid AND s.current_revision=:srev AND s.status='available'
                         AND NOT EXISTS (SELECT 1 FROM cmi.visibility_block b WHERE b.tenant_id=s.tenant_id
                             AND b.resource_kind='source' AND b.resource_id=s.source_id)'''),
                         {'t':tenant,'sid':str(source['source_id']),'srev':source['source_revision']})
                    if not permitted:
                        raise DomainError('SOURCE_UNAVAILABLE','Source authorization changed',409)
            conn.execute(text('''INSERT INTO cmi.memory_revision
                 (tenant_id,memory_id,revision,claim_text,assertion_kind,language,valid_from,
                  valid_to,confidence,confidence_method,extractor_id,extractor_version,
                  model_profile_ref,revision_status)
                 VALUES (:t,:mid,:r,:claim,:assertion,:lang,:vf,:vt,:conf,:method,:extractor,
                         :extractor_version,:profile,:status)'''),
                 {'t':tenant,'mid':str(mid),'r':rev,'claim':prev['claim_text'],
                  'assertion':prev['assertion_kind'],'lang':prev['language'],
                  'vf':prev['valid_from'],'vt':prev['valid_to'],'conf':prev['confidence'],
                  'method':prev['confidence_method'],'extractor':prev['extractor_id'],
                  'extractor_version':prev['extractor_version'],'profile':prev['model_profile_ref'],
                  'status':data.target_status})
            for source in refs:
                conn.execute(text('''INSERT INTO cmi.memory_source_link
                  (tenant_id,memory_id,memory_revision,source_id,source_revision)
                  VALUES (:t,:mid,:r,:sid,:srev)'''),
                  {'t':tenant,'mid':str(mid),'r':rev,'sid':str(source['source_id']),
                   'srev':source['source_revision']})
            conn.execute(text('''UPDATE cmi.memory_record SET current_revision=:r,status=:status,
                updated_at=clock_timestamp() WHERE tenant_id=:t AND memory_id=:mid'''),
                {'t':tenant,'mid':str(mid),'r':rev,'status':data.target_status})
            if data.target_status == 'revoked':
                conn.execute(text('''INSERT INTO cmi.visibility_block
                    (tenant_id,resource_kind,resource_id,reason_code,operation_id)
                    VALUES (:t,'memory',:mid,:reason,:op) ON CONFLICT DO NOTHING'''),
                    {'t':tenant,'mid':str(mid),'reason':data.reason_code,'op':str(uuid4())})
            conn.execute(text('''UPDATE cmi.context_bundle SET status='invalidated' WHERE tenant_id=:t
                 AND bundle_id IN (SELECT bundle_id FROM cmi.context_bundle_item
                     WHERE tenant_id=:t AND memory_id=:mid)'''),
                 {'t':tenant,'mid':str(mid)})
            self._event(conn,actor,'memory',str(mid),rev,f'cmi.memory.{data.target_status}')
            self._idem_commit(conn,actor,'memory.transition',key,
                              f'memory:{mid}:{rev}:{data.target_status}')
            return {'memory_id':str(mid),'revision':rev,'status':data.target_status,'replayed':False}

    def find(self, actor: Actor, mid: UUID):
        with self.transaction(actor) as conn:
            row = conn.execute(text('''SELECT m.memory_id,m.current_revision AS revision,m.status,m.kind,
                 m.scope_type,m.scope_ref,m.subject_ref,r.claim_text FROM cmi.memory_record m
              JOIN cmi.memory_revision r ON r.tenant_id=m.tenant_id AND r.memory_id=m.memory_id
                 AND r.revision=m.current_revision
              WHERE m.tenant_id=:t AND m.memory_id=:mid AND m.status='active'
                AND NOT EXISTS (SELECT 1 FROM cmi.visibility_block b
                    WHERE b.tenant_id=m.tenant_id AND b.resource_kind='memory' AND b.resource_id=m.memory_id)
                AND EXISTS (SELECT 1 FROM cmi.memory_source_link p WHERE p.tenant_id=m.tenant_id
                    AND p.memory_id=m.memory_id AND p.memory_revision=m.current_revision)
                AND NOT EXISTS (SELECT 1 FROM cmi.memory_source_link l
                    LEFT JOIN cmi.source_record s ON s.tenant_id=l.tenant_id AND s.source_id=l.source_id
                    WHERE l.tenant_id=m.tenant_id AND l.memory_id=m.memory_id AND l.memory_revision=m.current_revision
                       AND (s.source_id IS NULL OR s.status!='available' OR s.current_revision!=l.source_revision
                            OR EXISTS (SELECT 1 FROM cmi.visibility_block b
                                WHERE b.tenant_id=l.tenant_id AND b.resource_kind='source' AND b.resource_id=l.source_id)))'''),
               {'t':str(actor.tenant_id),'mid':str(mid)}).mappings().first()
            return dict(row) if row else None

    def search(self, actor: Actor, query: str, scope: Scope, top_k: int):
        with self.transaction(actor) as conn:
            escaped_query = query.replace('!', '!!').replace('%', '!%').replace('_', '!_')
            rows = conn.execute(text('''SELECT m.memory_id,m.current_revision AS revision,m.kind,r.claim_text,
                 m.status,m.scope_type,m.scope_ref,m.subject_ref FROM cmi.memory_record m
              JOIN cmi.memory_revision r ON r.tenant_id=m.tenant_id AND r.memory_id=m.memory_id
                 AND r.revision=m.current_revision
              WHERE m.tenant_id=:t AND m.status='active' AND m.scope_type=:type AND m.scope_ref=:scope
                AND (to_tsvector('simple',r.claim_text) @@ plainto_tsquery('simple',:q)
                     OR r.claim_text ILIKE '%' || :like_q || '%' ESCAPE '!')
                AND NOT EXISTS (SELECT 1 FROM cmi.visibility_block b
                    WHERE b.tenant_id=m.tenant_id AND b.resource_kind='memory' AND b.resource_id=m.memory_id)
                AND EXISTS (SELECT 1 FROM cmi.memory_source_link p WHERE p.tenant_id=m.tenant_id
                    AND p.memory_id=m.memory_id AND p.memory_revision=m.current_revision)
                AND NOT EXISTS (SELECT 1 FROM cmi.memory_source_link l
                    LEFT JOIN cmi.source_record s ON s.tenant_id=l.tenant_id AND s.source_id=l.source_id
                    WHERE l.tenant_id=m.tenant_id AND l.memory_id=m.memory_id AND l.memory_revision=m.current_revision
                     AND (s.source_id IS NULL OR s.status!='available' OR s.current_revision!=l.source_revision OR EXISTS (
                        SELECT 1 FROM cmi.visibility_block b WHERE b.tenant_id=l.tenant_id
                         AND b.resource_kind='source' AND b.resource_id=l.source_id)))
              ORDER BY m.updated_at DESC,m.memory_id LIMIT :lim'''),
              {'t':str(actor.tenant_id),'type':scope.type,'scope':scope.id,'q':query,'like_q':escaped_query,'lim':top_k}).mappings().all()
            return [dict(r) for r in rows]
