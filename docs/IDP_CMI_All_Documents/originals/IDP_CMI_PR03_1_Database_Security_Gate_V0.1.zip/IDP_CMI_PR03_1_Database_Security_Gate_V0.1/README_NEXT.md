# IDP-CMI PR-03.1 Database Safety Gate V0.1

This package carries the **unchanged PR-01–PR-03 implementation** with an **added real-database gate**. It does not claim real database test completion.

- Start here: `docs/PR03_1_GATE.md`
- Run on a disposable local PostgreSQL: `CMI_GATE_CONFIRM_DISPOSABLE=YES ./scripts/run_db_gate.sh --bootstrap-local`
- Run local unit checks only: `pytest -q` (database tests are skipped without DSN)
- Next sequence: PostgreSQL gate → fix concurrent first-source insert race → PR-04 Context Compiler.
