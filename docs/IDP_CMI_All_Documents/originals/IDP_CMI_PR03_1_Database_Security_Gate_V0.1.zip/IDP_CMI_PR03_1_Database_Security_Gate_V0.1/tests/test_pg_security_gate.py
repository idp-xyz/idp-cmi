"""Strict database role/RLS checks (requires real disposable PostgreSQL)."""
import os
from uuid import uuid4
from datetime import datetime, timezone
import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError
from idp_cmi.storage import Database
from idp_cmi.security import Actor
from idp_cmi.models import IngestRequest

URL=os.getenv('CMI_TEST_DATABASE_URL')
pytestmark=pytest.mark.skipif(not URL,reason='needs real disposable PostgreSQL')

@pytest.fixture(scope='module')
def db():
    instance=Database(URL)
    yield instance
    instance.engine.dispose()

def actor():
    tenant=uuid4()
    return Actor(tenant,'db-gate',frozenset({'source:ingest'}),frozenset({'memory'}),frozenset({f'tenant:{tenant}'}))

def source():
    return IngestRequest(source_system='db-gate',source_object_key='gate-'+str(uuid4()),
      source_revision=1,source_type='event',captured_at=datetime.now(timezone.utc),
      content_hash='sha256:'+'c'*64,content_location='s3://cmi-ingested/synthetic-test')

def test_app_role_is_unprivileged(db):
    with db.engine.connect() as conn:
        role=conn.execute(text("SELECT rolname,rolsuper,rolbypassrls,rolcreatedb,rolcreaterole FROM pg_roles WHERE rolname=current_user")).one()
        assert role[0]=='cmi_app', 'Must test with non-owner application role'
        assert all(v is False for v in role[1:])

def test_all_canonical_tables_have_force_rls(db):
    with db.engine.connect() as conn:
        rows=conn.execute(text("SELECT c.relname,c.relrowsecurity,c.relforcerowsecurity FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='cmi' AND c.relkind='r'")).all()
        assert len(rows)>=15
        assert all(row[1] and row[2] for row in rows)

def test_rls_denies_missing_and_other_tenant_context(db):
    own,other=actor(),actor()
    s=db.ingest(own,source(),str(uuid4()))
    with db.engine.connect() as conn:
        assert conn.scalar(text('SELECT count(*) FROM cmi.source_record WHERE source_id=:id'),{'id':s['source_id']})==0
    with db.transaction(other) as conn:
        assert conn.scalar(text('SELECT count(*) FROM cmi.source_record WHERE source_id=:id'),{'id':s['source_id']})==0
    with db.transaction(own) as conn:
        assert conn.scalar(text('SELECT count(*) FROM cmi.source_record WHERE source_id=:id'),{'id':s['source_id']})==1

def test_rls_rejects_cross_tenant_insert(db):
    own,other=actor(),actor()
    with pytest.raises(DBAPIError):
        with db.transaction(own) as conn:
            conn.execute(text('''INSERT INTO cmi.source_record
               (tenant_id,source_system,source_object_key,source_type,classification,source_trust,
                access_policy_ref,retention_policy_ref)
               VALUES (:tenant,'db-gate',:obj,'event','internal','external_untrusted',
               'poc:internal','poc:default')'''),{'tenant':str(other.tenant_id),'obj':'denied-'+str(uuid4())})
