#!/usr/bin/env bash
# Run ONLY against disposable local PostgreSQL.
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "${CMI_GATE_CONFIRM_DISPOSABLE:-}" != YES ]]; then
  echo 'Set CMI_GATE_CONFIRM_DISPOSABLE=YES after verifying a disposable database.' >&2
  exit 2
fi
if [[ "${1:-}" == --bootstrap-local ]]; then
  command -v docker >/dev/null || { echo 'docker is required' >&2; exit 2; }
  ./scripts/bootstrap_local_postgres.sh
  export CMI_TEST_DATABASE_URL="${CMI_TEST_DATABASE_URL:-postgresql+psycopg://cmi_app:local_app_dev_only@127.0.0.1:55432/cmi}"
fi
[[ -n "${CMI_TEST_DATABASE_URL:-}" ]] || { echo 'CMI_TEST_DATABASE_URL required' >&2; exit 2; }
python - <<'PY'
import os,sys
from urllib.parse import urlsplit
u=urlsplit(os.environ['CMI_TEST_DATABASE_URL'])
if u.scheme!='postgresql+psycopg' or u.hostname not in ('127.0.0.1','localhost','::1'):
    sys.exit('Database gate accepts local PostgreSQL only')
if not u.path or u.path=='/postgres':
    sys.exit('Use a disposable non-default database')
print('Database gate:',u.hostname,'port',u.port or 5432,'db',u.path)
PY
python -m pytest -q tests/test_postgres_integration.py tests/test_pg_security_gate.py
python -m pytest -q tests/test_api.py tests/test_domain.py tests/test_security.py tests/test_contract_static.py
