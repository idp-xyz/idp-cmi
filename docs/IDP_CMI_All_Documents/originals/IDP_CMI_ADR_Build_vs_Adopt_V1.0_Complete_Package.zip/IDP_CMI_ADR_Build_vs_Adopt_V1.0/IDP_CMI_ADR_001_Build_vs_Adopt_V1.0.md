# IDP-CMI 构建与复用架构决策记录（Build vs Adopt）V1.0

**文件编号**：CMI-ADR-001  
**版本/日期**：V1.0 / 2026-10-15  
**决策状态**：**Proposed / 待架构委员会评审批准**，尚未冻结到代码仓库、未上线、未经真实业务 PoC。  
**决策责任**：IDP 架构负责人（待指派）；产品责任人、数据安全负责人、技术负责人和法务参与会签。  
**上游输入**：`IDP_CMI_Core_Specification_V1.0.md`（五项核心契约及 G0–G7 验收）；`IDP_CMI_Enterprise_Memory_Infrastructure_RFC_V1.0.md`；IDP EER Whitepaper Master V2.0；HOST/EER 独立性决策。  
**范围**：独立可部署的 IDP Context & Memory Infrastructure (CMI)，不改动现有 EER / HOST 核心责任。

> 读者须知：本 ADR 定义要批准的技术方向、实施边界和验证准则；**不是** Hindsight、Mem0、Graphiti 性能已实测或 CMI 已建成的声明。项目功能/许可证来自 2026-10-15 核对的上游公开资料，生产功能与组件许可证还需锁定实际版本和依赖树再复核。

## 0. 决策摘要（Executive Decision）

### ADR-D01：采用「自主核心 + 成熟开源基础设施 + 适配器式算法组件」

- **BUILD（IDP 自主实现）**：CMI Public API 与独立服务框架、领域语义和 Canonical Store、Source/Memory 生命周期与版本账本、权限治理与撤权可见性、Context Compiler、Adapter Contract、跨引擎迁移/索引投影控制、证据和上下文清单。
- **ADOPT（直接使用开源基础）**：PostgreSQL、pgvector、PostgreSQL FTS、对象存储兼容 S3 协议实现；缓存使用 Valkey 或经许可证核对的 Redis 发行版。OIDC、遥测、队列等优先对接成熟组件而非自造协议。
- **EVALUATE（先评测再选择）**：Hindsight 作为第一 PoC 引擎；Mem0 为同数据集对照。**两者都尚未批准为生产主引擎**。只让引擎成为**派生记忆的候选生成和召回组件**，禁止其独占规范数据与授权决策。
- **DEFER（条件成熟再做）**：Graphiti/时序图投影、跨租户联合知识网络、专有向量集群、自学习治理、复杂反思控制循环。
- **REFERENCE ONLY（先参考，不直接绑定）**：OpenViking 的上下文分层组织和按需加载。主项目为 AGPLv3；任何部署/分发/托管服务方式的采用先法务审查，并校验具体组件许可证。

**主线技术决策不是“选 Hindsight 还是 Mem0”，而是“设计一个没有任何记忆引擎仍能完成安全读写、来源溯源和最小上下文编译的 CMI 内核”，然后把更智能的召回和反思作为增强组件接入。**

### 决策要点（必须区分）

1. **软件独立性**：CMI 独立启动、鉴权、读写、健康检测不依赖 HOST/EER 或 IDP MCP Infrastructure。
2. **数据权威性**：CMI Canonical Store 为 IDP 记忆记录、生命周期及授权可见性的权威；EER 是其 Execution/Evidence 的权威；ERP/WMS/Parcel 等是其业务事实领域的权威。三者不得混同。
3. **引擎可替换性**：开源引擎可以拥有自己的内部索引、cache、mental models/banks，但只作为**派生/候选状态**；没有规范化映射、删除传播和索引重建能力，不批准生产化。
4. **接口稳定性**：HOST/EER 只依赖 CMI 的版本化契约；不直接调用具体引擎的 `bank_id`、Graphiti node/edge 或内部表。
5. **安全性**：不得因为召回服务不可用、缓存命中或图谱关系而绕过权限，且在当前来源撤权后必须阻断新内容暴露。
6. **实现节奏**：优先模块化单体 + 异步 worker，不先拆分多个微服务。避免复制 EER 的调度器、State Machine 及业务执行层。

## 1. 背景与真实问题

企业 Agent 常需要跨会话召回客户规则、历史异常和经验；但仅有向量库会遗漏时序、来源与权限，直接绑定单一记忆框架又使 HOST/EER 遭到版本、Schema 和许可锁定。IDP 已有 EER，且 HOST 被设计为无 EER 也可完成核心工作闭环。CMI 应支持这两者，同时成为可对外提供的独立基础设施。

**成功不等于**能回答“用户以前说过什么”，而是能在授权与业务有效时点下回答“本次任务应该得到哪些经过来源追溯的信息”，同时可以可靠撤权、审计、迁移与复现；仍由业务 SoR 返回事实并由 EER/获准业务服务执行动作。

**不做**：通用 Agent Runtime、LLM Serving、流程编排、业务副作用/补偿、作为 EER Evidence 唯一存储；也不另造一个 MCP Gateway/Registry/路由治理产品。

## 2. 备选路线评估

| 路线 | 架构控制权 | 初期速度 | 长期替换成本 | 不可接受的条件 | 决策 |
|---|---|---|---|---|---|
| A. 全部自研，包括嵌入/ANN/图存储/记忆算法 | 高 | 慢 | 持续基础算法维护大 | 严重占用产品治理研发 | Reject |
| B. Fork Hindsight/Mem0，业务逻辑改在其主仓库中 | 低至中 | 快 | 深度上游耦合，升级冲突 | CMI 数据主权失控 | Reject as primary architecture |
| C. 自主领域核心 + 开源基础设施 + 适配器 | 高 | 中等 | 受控，需自己承担胶水/兼容层 | 必须兑现独立验收和工程规范 | **Proposed Accept** |
| D. 纯自研薄封装，记忆只存入某 SaaS | 低 | 很快 | 数据出域与费用/可用性锁定 | 不满足独立私有化目标 | Reject for core |

**反证条件**：若实施成本显著高于真实客户需求，可先用 Hindsight 为单一产品建立受限 PoC，**但不得把该 PoC 的引擎内部模型宣布为 CMI 公共契约**。服务独立的价值须在 Parcel 等真实案例的接入与维护成本中验证。

## 3. 功能模块级决策矩阵

决策缩写：**B** 自研；**A** 直接采用；**P** 插件对照 PoC；**R** 研究参考；**D** 延后。每个模块必须在 `decisions.csv` 中可追踪；这里显示结构主线。

| 编号 | 模块 | 策略 | 默认候选 | 决策与验收理由 |
|---|---|---|---|---|
| CMI-01 | Public REST/gRPC API | B | IDP | CMI 自有版本、错误和授权模型；不暴露引擎专名 |
| CMI-02 | MCP Server Adapter | B + A SDK | MCP 2026-07-28 SDK | 仅协议适配，无内嵌 Gateway；新正式版优先，不兼容旧版的专属桥接不在范围 |
| CMI-03 | SourceRecord Registry | B | PostgreSQL | 来源、哈希、版本、删除依赖必须可控 |
| CMI-04 | MemoryRecord/Revision Ledger | B | PostgreSQL | Canonical claim 与版本、双时态、CAS |
| CMI-05 | ContextBundle/Manifest | B | PostgreSQL + 对象存储 | 复现、出处、模型版本与当前有效性复核 |
| CMI-06 | Lifecycle/Erasure Coordinator | B | 事务 + outbox worker | 撤权同步屏蔽，派生索引异步清理可跟踪 |
| CMI-07 | Identity & Tenant Access | B 集成层 + A IdP/PDP | OIDC / 已有企业 IAM | 自主策略实施；不自造 OAuth/OIDC 协议栈 |
| CMI-08 | Domain Policy & ACL Recheck | B | 应用强制 + PostgreSQL RLS | 服务端授权，拒绝客户端 `tenant/status/trust` 自报 |
| CMI-09 | Retrieval Federation / Ranking | B 组合层 + A 基础检索 | FTS + pgvector | 有来源、范围和授权后再聚合候选 |
| CMI-10 | Embeddings | A 可切换 | 本地或获准 API 模型 | 版本维度/驻留/隐私统一登记，禁止静默换 embedding |
| CMI-11 | Memory Extraction | P | Hindsight 与 Mem0 | 谁准确、便宜、可删除，须同数据验证 |
| CMI-12 | Reflection / Experience Extraction | P / D | Hindsight | 反思输出保持候选；程序性升级需人工/政策审核 |
| CMI-13 | Context Compiler | B | IDP | 权限、时序、token 预算、优先级与稳定清单 |
| CMI-14 | Approximate Vector Search | A | pgvector | 自研 ANN 没必要；安全过滤/召回需评测 |
| CMI-15 | Text Index | A | PostgreSQL FTS | 基础词法召回，先不引入第二搜索集群 |
| CMI-16 | Temporal Knowledge Graph | D + P | Graphiti | 真实多跳/时态收益证明后启用；避免重复主索引 |
| CMI-17 | SQL / Metadata Persistence | A | PostgreSQL | 事务、扩展能力与工具生态成熟 |
| CMI-18 | Cache / TTL | A | Valkey / Redis 经版本核实 | 仅加速；缓存不可成为授权唯一依据 |
| CMI-19 | Object Store | A | MinIO/其他 S3-compatible | 许可证、部署版本、加密/KMS 需单独审查 |
| CMI-20 | Async Outbox/Workers | B 领域逻辑 + A 基建 | PostgreSQL outbox + worker | 先不引入第二分布式消息平台；必要时接 Kafka |
| CMI-21 | Observability | A 底座 + B 指标 | OpenTelemetry/Prometheus | 源文本/PII 不写普通 tracing |
| CMI-22 | Engine Adapter/Compatibility | B | CMI SPI v1 | 需要禁用/迁移/重建/删除事件 ACK 等语义 |
| CMI-23 | OpenViking context filesystem | R | 独立架构研究 | 核心 AGPLv3，严禁默认为可闭源集成 |
| CMI-24 | Multi-region / Dedicated clusters | D | 待 SLO 与合同验证 | V1 不提前引入多活系统复杂度 |

## 4. 逻辑与部署架构

```mermaid
flowchart TB
  HOST[IDP HOST] -->|optional Context API| API
  EER[IDP EER] -->|optional events/search| API
  THIRD[3rd-party Hosts/Apps] -->|authorized API| API
  MCPINF[IDP MCP Infrastructure] -. optional mediation .-> MCPAD[MCP Adapter]
  MCPAD --> API
  subgraph CMI[IDP-CMI independent service]
    API[CMI API + Policy Enforcement] --> COMP[Context Compiler]
    API --> LIFE[Source/Memory Lifecycle]
    LIFE --> REG[(Canonical Registry + Version Ledger)]
    LIFE --> OUT[(Transactional Outbox)]
    OUT --> PROJ[Projection Workers]
    PROJ --> ENGINE[Pluggable Engines: Hindsight / Mem0 / Graphiti]
    PROJ --> VEC[(FTS / pgvector)]
    COMP --> RET[Authorized Retrieval]
    RET --> REG
    RET --> VEC
    RET --> ENGINE
    COMP --> BUND[(Context Manifest Store)]
  end
  API -. token validation .-> IAM[Enterprise IAM / PDP]
  BUND --> OS[(Object Store)]
  REG --> OS
```

部署 P0：`cmi-api` 单进程或单服务（可水平扩）、`cmi-worker` 异步任务、PostgreSQL+pgvector/FTS、获准的对象存储、可选缓存；记忆引擎为**独立进程/容器**，有单独 service credential 和禁止对公网直露的管理 API。单机 Docker Compose 可开发，生产 Kubernetes/独立虚机均可，但**逻辑模块不等于要求微服务拆分**。

### 4.1 与 IDP MCP Infrastructure 的关系（重要）

CMI 对外可提供直接 REST/gRPC API 和 **标准 MCP Server 能力**；IDP MCP Infrastructure 是独立 MCP 连接与治理产品，可选择代理 CMI 的 MCP Server，但 **CMI 的独立部署、鉴权、读写、健康检查不得依赖它**。MCP Infrastructure 不接管 Memory Lifecycle/数据授权；CMI 不重造 Registry、通用 Gateway 和 MCP Client/Host。

**协议边界**：针对 IDP 已定 2026-07-28 最新正式 MCP 基线，CMI MCP Adapter 仅面向 **Modern Stateless** 核心：每个请求带版本与能力元信息；HTTP POST；无旧式 `initialize`、会话或 `Mcp-Session-Id` 适配，不引入 Legacy Adapter。与标准 Server/Client 的兼容测试在协议层执行，但 REST/gRPC 业务能力与 MCP 无耦合。

**避免误用**：不因为 Hindsight 内置 MCP endpoint 就直接允许其暴露生产租户数据。必须通过 CMI Policy Enforcement 或经形式化验证能等价执行授权的代理层，且不得信任仅由请求给出的 `bank_id`。

## 5. Canonical vs Engine State：数据主权契约

### 5.1 三种数据必须分开

| 类别 | 权威持有者 | 举例 | 引擎崩溃处理 |
|---|---|---|---|
| 原始权威业务事实 | Parcel/ERP/WMS/EER 各自业务域 | 当前运单状态；ExecutionRecord/Evidence | 必须回源核验，不以记忆替代 |
| CMI 规范记忆与来源账本 | CMI Canonical Store | SourceRecord、MemoryRecord/revision、授权、有效期、删除状态 | CMI 仍可查询元数据/FTS；重建派生能力 |
| 引擎衍生状态 | 独立 Engine Store（非权威） | bank/向量索引/内部知识图/反思模型 | 标记缺失并重建；安全回退/降级 |

核心挑战不只是同步复制两个数据库。**引擎提取的候选必须投递回 CMI 经统一规则验证、去重并写入 Canonical Store。**引擎侧自主产生的新事实、推断和修订若不经过 CMI，不得直接进入公共检索输出。

### 5.2 写管线（write ownership）

1. 外部提交 `SourceIngestRequest`；CMI 自行校验身份、purpose、来源权限，创建 SourceRecord；禁止传入可直接生效的状态/权威度。
2. Registry 与 transactional outbox 同事务提交 `SourceAccepted`；异步引擎可抽取 candidate claims；外部处理器只拿到合规最小材料。
3. CMI 将 candidates 标准化，校验每个 claim 的 `source_refs`、租户和有效时间；检查与现有 claim 冲突、重复及适用范围。
4. Policy + 规则（需要时人工审批）决定候选可否转为 `active`；**源授权变化可以随时阻断可见性**。CAS 写新 revision 与 outbox。
5. Outbox worker 幂等投影 FTS/vector/可选图谱；记录 `generation`, `projection_watermark`, 失败重试与 Dead Letter。

**一致性**：CMI Registry 是事务锚点；衍生系统采用可观测的最终一致。`engine_ack` 是投影处理回执，不是事实获批或业务执行成功。

### 5.3 读管线（read ownership）

`authn + purpose` → `effective ACL prefilter` → `FTS/vector/engine candidates` → `registry resolve by IDs` → `valid_time/known_at/scope/classification/current policy recheck` → `dedup/rerank` → `cite sources` → `Context Compiler packing`。

引擎返回纯文本但**无法可靠映射到规范 memory_id/revision/source_refs** 的情况：**不得以“可信历史事实”身份进入 ContextBundle**。可作为独立 `external_untrusted` 建议经过约束后候选使用，或直接拒绝该引擎的生产接口。这个限制须写进 PoC Gate。

### 5.4 删除、撤权和迁移

- `revoke` 必须以 CMI 主账本**同步不可见**开始，旧索引/引擎未删净不能继续外泄。
- `erase` 清除原文、规范记录明文、向量、图、引擎 bank、缓存、可读 Bundle、派生摘要；向外引擎/供应商发出 `delete request` 并跟踪回执与法定例外。
- 对引擎不支持删除某条 claim、只能删除整个 bank 的情况，必须证明 **bank 粒度和租户/作用域的映射安全**，或者以重建策略确保可验证的彻底移除；否则拒绝其生产资格。
- 迁移时采用 canonical snapshot → 新引擎 projection → 双引擎影子召回（返回只以主链判定）→ 一致性/准确率验证 → 受控切换；禁止两个引擎竞争写同一记忆规范版本。
- 保留“最小合法擦除 Tombstone”而不留存可重识别正文；加密备份/PITR 恢复必须经过撤权/擦除屏蔽重放，再重新对外提供服务。

## 6. CMI Memory Engine SPI V1（方案级合同）

下表为内部插件能力，**不是**任何具体开源项目已满足的声明。

| 方法/事件 | 必需 | 功能 | 失败语义 |
|---|---|---|---|
| `health()` | MUST | 引擎健康和版本/模型配置 | 超时快速降级 |
| `extract(source_ref,content_ref,profile)` | P0 MUST for extraction-enabled plugin | 返回结构化候选 + 来源锚点 | 失效不会更改规范主账本 |
| `index(records,generation,idempotency_key)` | MUST | 已批准数据的派生索引 | 至少一次投递，幂等去重 |
| `search(query,scope,filters,top_k)` | MUST | 返回可映射的候选规范 IDs | 不可映射拒绝投影级可信结果 |
| `delete(ids_or_scope,operation_id)` | MUST | 派生记忆完整删除 | ACK 附 scope/count/版本；需后验扫描 |
| `rebuild(snapshot_ref,generation)` | MUST | 独立从规范主账本重建 | 可回滚的双 generation 管理 |
| `capabilities()` | MUST | versions/filter/deletion/costs/mcp 等声明 | 能力不足则禁用对应 feature |
| `reflect(...)` | OPTIONAL | 产生经验/建议 candidate | 不得修改 active 或批准策略 |
| `graph_query(...)` | OPTIONAL | 多跳与有效时间查询 | 结果回 Registry 核验 |

**强制限制**：任何引擎 API 不得接收应用方自行构造的授权结论；所有外送 LLM/tokenizer/embedding 必须登记数据驻留和配置版本。进程级强隔离与网络出站限制可按敏感级别配置。

**兼容评估关键项**：删除粒度、跨租户数据边界、引擎内部自行 consolidation 是否可被 CMI 禁止/审计、是否支持精确回溯 SourceRef、embedding 维度/版本与全量重建、版本锁定、备份还原、是否允许同主库共享 pgvector（默认否，以免耦合 schema）。

## 7. 开源技术尽调：证据与不确定性

| 项目 | 核验到的上游能力/许可 | IDP 首期角色 | 尚未证明的问题 |
|---|---|---|---|
| [Hindsight](https://github.com/vectorize-io/hindsight) | 公开 MIT；Retain/Recall/Reflect；自托管；PostgreSQL/pgvector；内置 MCP endpoint | 优先 PoC candidate extraction/retrieval | 删除传播粒度、claims ID 回映射、隔离、内置自主反思造成的权威越界、开销 |
| [Mem0](https://github.com/mem0ai/mem0) | 公开 Apache-2.0；memory add/search/update/delete | 同条件对照 PoC | 更新覆盖/时间事实、删除确认/副本、来源粒度、稳定性 |
| [Graphiti](https://github.com/getzep/graphiti) | 公开 Apache-2.0；动态/时序图谱、关系查找 | 特定多跳需求的 P1 实验插件 | Graph DB 运维成本、图/内存双写不一致、跨租户图泄漏 |
| [OpenViking](https://github.com/volcengine/OpenViking) | 当前 README：主项目 AGPLv3，部分子目录 Apache-2.0 | 研究 L0/L1/L2/context filesystem，不直接嵌入 | 商业使用许可、派生作品和网络服务义务、版本/license 混用 |
| [pgvector](https://github.com/pgvector/pgvector) | Postgres 内向量检索，HNSW/IVFFlat；文档警示 ANN 过滤后置及多租户索引干扰 | 直接采用 | 指定数据规模与 ACL 下 recall/latency/partition 实测 |
| [MCP 2026-07-28](https://blog.modelcontextprotocol.io/posts/2026-07-28/) | Modern Stateless、无协议 session 与旧 initialize；版本元信息每请求 | MCP Adapter 协议目标 | SDK 的特定 release 能否完整覆盖需求的测试 |

**许可证清单**必须由发布团队生成 SBOM，包括 transitive deps、容器基础镜像、SDK、模型权重许可证以及 MinIO/Redis 实际选择版本；不能仅凭仓库根目录 LICENSE 推断整个分发包全是同一许可证。需要 LEGAL-01 完成商业合规会签才可进行对外收费部署。

**性能声明边界**：不引用厂商基准作为性能结论；厂商描述的生产实践不替代我方实际测量。不把“独立部署”误写成“完全无依赖”，需要数据库、密钥/鉴权及其他配套服务。

## 8. 具体 PoC 方案：同数据集、同模型、同预算

### 8.1 三组被测方案

- **S0 Baseline**：CMI Canonical Store + PostgreSQL FTS/pgvector + 最小规则检索，**无专业记忆引擎**。
- **S1**：S0 + Hindsight Adapter（独立服务、锁定版本）。
- **S2**：S0 + Mem0 Adapter（独立服务、锁定版本）。

相同的输入、授权身份、实体版本、tokenizer、embedding / LLM 可比配置、硬件与成本统计口径。某引擎需要不同模型时分两组报告：**产品默认配置结果**与**尽可能控制变量的配置结果**。所有选型都必须通过 S0 确认内核可以退化运行。

### 8.2 评测数据建议

构建 **240 个任务样本（初始建议值，不是已经拥有的数据）**，包含正常记忆回忆、客户规则变更、冲突事实、跨多会话、时间点回溯、用户撤权/擦除、Prompt Injection、跨租户越权、Source 撤回、Parcel 地址/门牌/渠道异常、EER Evidence 来源引用和反思经验治理。每个样本由行业人员标注真值、必引来源、允许/禁止记忆、时序窗口、预期行为。分为公开合成与经审批脱敏真实数据；测评数据禁止用未经授权的客户生产数据。

### 8.3 必过安全/架构 Gate（任何一项失败不准入）

- **GATE-A1 主权**：关闭/卸载所有外部引擎，CMI 可独立完成 canonical 读写、RLS/ABAC、基本检索及上下文编译；HOST/EER 无 CMI 仍能独立运行。
- **GATE-A2 语义**：引擎结果可确定性映射回当前有效 `memory_id/revision/source_refs`；不能只有不透明答案文本。
- **GATE-A3 授权**：跨租户、跨主体、撤权后、过期源的非授权明文输出为 **0 次（在覆盖的测试中）**；不承诺测试之外绝对无漏洞。
- **GATE-A4 删除**：完成规范/引擎/索引/缓存/快照删除流程且保存可核验完成证据；不支持删除的引擎不得被选为生产插件。
- **GATE-A5 迁移**：canonical → 新引擎重建可重复；切换中无失效旧内容重新变可见。
- **GATE-A6 合规**：许可证、数据驻留、供应商调用及 SBOM 会签，缺失不可对外商用。

### 8.4 可加权比较的质量/成本指标（仅在所有 Gate 通过后）

| 指标 | 定义 | 建议权重 | 报告说明 |
|---|---|---:|---|
| Grounded recall@k | gold 支持事实在可追溯结果中的覆盖 | 25% | 在同召回预算下报告 |
| Temporal correctness | 双时态与冲突事实的准确判断 | 20% | 与业务事件生效/登记时间分开 |
| Context answer quality | 基于固定 prompt 和 token 预算输出的正确性 | 20% | 人工复核 + 可复验自动度量 |
| P95 latency | 用户可感知检索/编译延迟 | 10% | 冷/热、租户规模和退化模式分列 |
| Cost per 1000 tasks | LLM、embedding、数据库、存储、基础设施 | 10% | 不只计算 token |
| Delete/rebuild operability | 删除/重建耗时、失败率、手工操作量 | 10% | Gate 通过之外比较维护性 |
| Upgrade/license/operations | 上游版本变更、运维复杂度、合规开销 | 5% | 审计打分并附证据 |

上表权重是待确认的**选型政策建议**，不是预先断言谁领先；性能上线阈值须依据真实工作负载基线与客户 SLA 制定，不虚构目前的 P95 毫秒值或收益百分比。**综合分不能覆盖安全 Gate 的否决权。**

### 8.5 结论分支（避免预设答案）

- 若 S1 通过所有 Gate 且显著提升任务效果/总成本优于 S0，则选用 Hindsight 为 **Version-pinned Engine Plugin**。
- 若 S2 优于 S1 且过关，则选用 Mem0。
- 若两者有无法修复的删除/回溯/授权映射问题，则维持 S0，先自研有限的候选抽取/混合检索，暂不引入专业引擎。
- Graphiti 只有在某些跨实体时序查询对 S0/S1/S2 带来经验证的明显新增收益时，进入下一轮试点。

## 9. 风险登记与控制

| ID | 主要风险 | 概率/影响（预评） | 对应控制 | Gate |
|---|---|---|---|---|
| R-01 | 引擎自行 consolidation 改写/泄露记忆 | 中/高 | 非权威隔离、候选回写批准、版本对账 | A2 |
| R-02 | HNSW 多租户过滤导致漏召回 | 中/中高 | RLS + 分区/精确候选集 + recall 回归 | A3 |
| R-03 | 授权变更与缓存/Bundle 复用竞争 | 高/高 | 读取及消费前复验策略版本、deny by default | A3 |
| R-04 | 源删除不传播到嵌入/图/快照 | 高/高 | 依赖边、撤权同步屏蔽、删除回执与扫描 | A4 |
| R-05 | 上游升级变更 schema / 默认行为 | 中/中 | Pin digest/commit、隔离适配、CI 兼容测试 | A5 |
| R-06 | AGPL/其他组件/模型权重合规误判 | 中/高 | SBOM + 法务评审 + 许可清单 | A6 |
| R-07 | CMI 记忆被误认为 SoR 事实 | 高/高 | authority_scope + source label；SoR 校验、禁止执行副作用 | A2 |
| R-08 | 提示注入通过检索转为执行指令 | 高/高 | 内容数据隔离、信任标记、低信任不入系统消息 | A3 |
| R-09 | 双引擎重复写导致不可重复生命周期 | 中/高 | 一个 CMI 主账本、引擎只为投影，不做主写者 | A1/A5 |
| R-10 | 本地模型质量不足或 GPU 资源冲突 | 中/中 | 模型可配置、离线评测、配额和回退 | POC |
| R-11 | MCP Infrastructure/CMI 双重治理相互冲突 | 中/中 | Transport Auth 与数据授权边界分离 | A1/A3 |

## 10. 责任界面：HOST / EER / MCP Infrastructure / CMI

| 场景 | 发起方 | 权威责任 | CMI 执行 | CMI 明确不执行 |
|---|---|---|---|---|
| HOST Chat / AgentRun | HOST | 会话及 AgentRun 状态 | 构建可追溯 ContextBundle | 代管 AgentRun 或工具执行 |
| EER 业务事件与证据 | EER | Execution State、Evidence、Verifier | 引用、索引、经审批提炼经验 | 重写 EER Evidence；判断业务最终成功 |
| Parcel 订单/运单实时信息 | Parcel | 当前事实/字段有效性 | 历史案例检索；创建来源引用 | 修改业务对象或替代实时验证 |
| MCP 协议入口 | CMI MCP Server 或 MCP Infrastructure | 各自接口/网关及传输层 | 核验自身请求身份/内容授权 | 把 MCP 网关当作 CMI 内部数据库授权者 |
| Client 无法连接 CMI | HOST/EER 自行负责退化 | 其核心业务闭环 | CMI 无法保证可用 | 强制拦截/替换其执行路线 |

## 11. 执行工单与依赖顺序（Technical Design 输入）

| 里程碑 | 实施任务 | 工件 | 验收依赖 |
|---|---|---|---|
| T0 评审冻结 | ADR 会签、许可候选白名单、数据处理目的矩阵 | ADR Accepted + decision log | 组织批准 |
| T1 无引擎内核 | PostgreSQL DDL、RLS、Source/Memory/Bundle API、事务 outbox | Migration + API Integration Tests | G0–G4 |
| T2 基础检索 | FTS/pgvector、受控编译、Bundle 复验、撤权 & erasure | Retrieval/Privacy Suite | G5–G6 |
| T3 Adapter + PoC | Hindsight/ Mem0 沙箱集成、240 样本、成本与召回数据 | Runbook + Result Table | GATE-A1…A6 |
| T4 Parcel 验证 | HOST/EER/Parcel 授权只读与执行结果回传 | 真实案例回放、业务归因 | G7 |
| T5 生产门槛 | 威胁建模、密钥/审计、备份恢复、负载/DR、许可证 | Go-Live Signoff | 生产准入 |

**第一批开发不得做**：Graphiti 生产化、长期自主策略自学习、通用跨企业分享、自动“记忆→EER 指令”、对 MCP 旧协议兼容层、独立打造 Vector DB、再写一个企业 Agent Runtime。

## 12. 直接写入下一版 Technical Design 的接口清单

- `storage/canonical`：SourceRecord、MemoryRecord revision、ContextBundle、policy_ref、source→memory→bundle 依赖表、tombstone/erasure_request、outbox_event、projection_checkpoint、engine_mapping。
- `domain/lifecycle`：`propose`, `transition(expected_revision)`, `invalidate(source_ref)`, `erase(op_id)`，事务/重入/并发/重放状态机。
- `security`：`authorize(principal,purpose,action,resource)`，read prefilter 与 post-check，RLS，token `iss/aud/scope`，Bundle read-time validation。
- `retrieval`：`search(query,valid_time,known_at,scope)`，FTS+vector merge，candidate→canonical resolve，freshness & trust filter，ranker。
- `context`：`compile(task,model_profile,budget)`，包预算、固定字段、来源引用、manifest 与 hash、不可把检索文本提升为 system 指令。
- `engines`：`EngineAdapterV1`、capability matrix、HindsightAdapter、Mem0Adapter（仅 PoC）、rebuild/delete/ACK/telemetry。
- `adapters`：HOST Context Consumer、EER Evidence/Event Consumer、CMI Modern MCP Server Adapter（均独立可选）。
- `test`：schema、跨租户、时序、撤权、erase、migration、no-engine fallback、MCP 互操作、Parcel 回归。

## 13. 拟议验收及决策批准记录

| 决策项目 | 申请批准的结论 | 当前状态 |
|---|---|---|
| 001 核心路线 | 自主核心 + 开源基础 + 可插拔引擎 | Proposed |
| 002 数据主权 | CMI Canonical Store 是记忆有效性/授权主账本 | Proposed |
| 003 选型 | Hindsight 首轮 PoC、Mem0 同条件对照；不提前选主引擎 | Proposed |
| 004 Graphiti | 证明复杂图谱收益后再引入 | Proposed |
| 005 OpenViking | 参考研究为主；具体采用需独立许可评审 | Proposed |
| 006 MCP | 独立 CMI Server Adapter，仅 2026-07-28 Modern Stateless；可选与 MCP Infra 集成 | Proposed |
| 007 安全 | ABAC + 来源依赖、撤权同步屏蔽、擦除异步核实 | Proposed |
| 008 部署 | P0 模块化单体 + worker，后续按 SLO 拆分 | Proposed |

**批准所需签名字段**：Architecture Owner ______；Security/Data Owner ______；Engineering Owner ______；Product Owner ______；Legal Reviewer（许可项）______；批准日期 ______。被批准前文件状态仍为 Proposed，不代表已经完成上述签名。

## 14. 一手资料索引与核验说明（截至 2026-10-15）

1. [Hindsight GitHub / MIT / Retain-Recall-Reflect / Deployment](https://github.com/vectorize-io/hindsight)；此处描述官方功能，未独立验证对 CMI 自有契约的适配能力。
2. [Mem0 GitHub / Apache-2.0](https://github.com/mem0ai/mem0)；OSS 与商业服务功能边界以当前发布包为准。
3. [Graphiti GitHub / Apache-2.0](https://github.com/getzep/graphiti)；不是旧版 Zep CE。
4. [OpenViking GitHub / 各组件分许可证](https://github.com/volcengine/OpenViking)；当前主项目 AGPLv3，局部模块 Apache-2.0。
5. [pgvector 官方 README / ANN Filter & Multitenancy](https://github.com/pgvector/pgvector#filtering)，多租户向量共享索引会影响 recall。
6. [Model Context Protocol 正式 2026-07-28 版本说明](https://blog.modelcontextprotocol.io/posts/2026-07-28/)；[变更日志](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/changelog.mdx)。
7. [MCP 2026-07-28 Overview](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/basic/index.mdx)；[HTTP Authorization Tutorial](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/docs/2026-07-28/tutorials/security/authorization.mdx)。

**证据强度分级**：上述仓库/规范可支持“公开文档列出某能力与许可”；不能替代指定版本依赖树的法律确认、真实负载性能测试、商用 SLA 或 CMI 的功能完整性验收。

---

**ADR 状态变更记录**
- V1.0 / 2026-10-15 — Proposed；完成模块级 Build/Adopt 边界、接口安全门槛与 PoC 方案；待会签与真实实现。
