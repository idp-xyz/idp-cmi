# IDP-CMI ADR 工程决策交付包 V1.0

**制作日期：2026-10-15**；**性质：正式评审草案 Proposed，尚未批准或投入生产**。文件可在完全离线环境下查看。

| 文件 | 用途 |
|---|---|
| `IDP_CMI_ADR_001_Build_vs_Adopt_V1.0.md` | ADR 正文，涵盖方案比较、24 模块责任、数据主权、接口、License、PoC 与审批门槛 |
| `IDP_CMI_ADR_001_Build_vs_Adopt_V1.0.html` | 单文件离线专业阅读版，内嵌架构图，支持检索与打印 |
| `architecture.svg` / `architecture.dot` | 可复用架构图（DOT 可编辑） |
| `module_decisions.csv` | 24 个模块的 Build / Adopt / PoC / Defer 机器可读决策清单 |
| `PoC_Evaluation_Protocol_V1.0.md` | 240 样本计划、六大 Gate、指标与分数规则，所有结果均待测试 |
| `poc_seed_cases.csv` | 40 个**合成测试场景模板**，不是跑过的评测用例 |
| `poc_scorecard_template.csv` | S0/S1/S2 三组评测记录空白模板，不包含虚构分数 |
| `Technical_Design_Handoff_V1.0.md` | 供 Codex/技术团队下阶段推进的任务、代码结构与 PR 分解 |

**必须同时参考既有材料**：`IDP_CMI_Core_Specification_V1.0_Complete_Package.zip` 中的 Schema 与 OpenAPI；本交付包不擅自替换既有契约。

**起步执行**：先由架构、产品、安全和法务批准 ADR，再开发 S0 无引擎可运行内核；只有 PoC 六个 Gate 全通过后才批准某个生产记忆引擎。
