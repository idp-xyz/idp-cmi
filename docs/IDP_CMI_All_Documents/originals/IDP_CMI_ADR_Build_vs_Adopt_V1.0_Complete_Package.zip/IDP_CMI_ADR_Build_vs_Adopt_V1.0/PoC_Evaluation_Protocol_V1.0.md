# IDP-CMI PoC Evaluation Protocol V1.0

**状态：评测计划 / 尚未运行**。不得将空白 `poc_scorecard_template.csv` 当作测试成绩。

## 1. 可复现数据计划

- **总量目标 240 个独立任务实例（待采集/标注）**，40 个 `poc_seed_cases.csv` 只是**合成用例模板**，不是 40 份已标注数据。
- 配额：记忆与跨会话 40，双时态/冲突 35，权限/隔离/删除 45，Parcel 业务 55，EER/证据/执行边界 25，注入/鲁棒/退化 25，成本/性能/升级 15，共 240。
- 标注字段：principal / tenant / purpose、知识来源、valid_time / known_at、expected memory ids/revisions、拒绝输出清单、权威 SoR 对照、模型配置、任务期待结果、人工标注人及审签记录。
- 数据分类：SYNTHETIC（开发用），SANITIZED-REAL（审批脱敏后评估），CONFIDENTIAL（只能在获准内网使用）；未经授权的数据不能上传第三方云模型。
- 数据集必须版本化、避免 train/eval 泄漏。PoC 运行时使用 **冻结的数据快照 + 相同访问策略**。

## 2. 对照系统

| System | 实现 | 说明 |
|---|---|---|
| S0 | CMI + PostgreSQL FTS + pgvector | 最小自主内核，必须能独立工作 |
| S1 | S0 + Hindsight Adapter | 供应商自带记忆能力，非权威派生组件 |
| S2 | S0 + Mem0 Adapter | 与 S1 同数据、授权、预算、模型配置尽量一致 |

必须记录：Git commit/release、容器 digest、Python/SDK version、索引参数、输入 token、输出 token、模型定价快照、机器规格、warm/cold/并发数、数据集版本、总预算以及请求级 trace ID。

## 3. 强制准入 Gate（必须全部 PASS）

| Gate | 判定目标 | 必须提交的客观证据 |
|---|---|---|
| A1 | 关闭引擎后安全可用、独立启动 | 连续集成 integration test + 短时断网注入 |
| A2 | 输出可严格回映射到 canonical IDs 与 source refs | 结果 provenance linkage test，不能只有不透明自然语言 |
| A3 | 访问权限/撤权/注入场景不出现未授权输出 | negative security test + 审计记录 |
| A4 | 删除覆盖主库、索引、引擎、cache、Bundle、备份恢复屏蔽 | erasure receipt + 后验 probe + 合法保留例外记录 |
| A5 | 旧引擎→新引擎可恢复重建及稳定切换 | snapshot/version/checkpoint/roll-back 记录 |
| A6 | 依赖许可、分发包和数据处理供应商可用于预定商业部署 | SBOM、许可证审核、供应商驻留清单、签字 |

**安全测试“0 次泄漏”只指测试覆盖集内必须为 0，不意味着声称系统不会在其他场景中出现安全问题。**

## 4. 可量化指标及方法

1. `grounded_recall@k` = 在允许召回且有金标证据的任务中，前 k 个**有合法 source_ref** 的结果覆盖目标事实任务数 / 对应评估任务总数。
2. `temporal_correctness` = 正确执行 valid_time / known_at 双时态筛选的任务数 / 时间类任务总数。
3. `context_answer_quality` = 在固定评审量表上，由至少两位评审对事实完整、引用正确、遗漏风险的评定；分歧需仲裁记录。
4. `p95_search` 与 `p95_compile` 按冷、热、并发分别报告；保留超时和 5xx，不只报告成功样本。
5. `total_cost/1,000 tasks` = API / LLM / embedding / DB / GPU 折旧估算 / 运维摊销 / storage 及出网成本；需注明假设。每次任务服务端账单/显卡功耗可能需要另行计量。
6. `deletion completion` = 从撤权同步屏蔽至各对象、索引、引擎回执和抽查通过的时长；逻辑不可见与物理删除分开记录。
7. `migration effort` = 从快照到重建、字段兼容、回滚及对账所需工时和数据丢失情况。

## 5. 打分规则（仅 Gate 全部 PASS 才能比较）

| 指标 | 权重 |
|---|---:|
| Grounded recall@k | 25% |
| 双时态正确性 | 20% |
| Context answer quality | 20% |
| P95 Latency | 10% |
| 每千任务总成本 | 10% |
| 删除/重建可维护性 | 10% |
| 升级/许可证/运维难度 | 5% |

所有指标归一化公式与上下限必须在**揭盲/测量前预先登记**，避免事后调整权重偏袒某个引擎。单一指标对主业务存在硬 SLO 的，单列 SLO Gate，不能由综合分抵消。

## 6. 试验流程

1. 环境冻结与威胁建模：录入具体版本、许可证和硬件、网络/出域清单。
2. 安全/独立性预检：先通过 A1/A3 的关键负面用例。
3. 数据摄入：相同 source 对每组清空环境导入；保存数据 hash 和 outbox 水位。
4. 运行任务：随机化任务顺序，固定并发分层，记录完整耗时与错误。
5. 人工复核：行业人员 blind review 对事实质量与操作风险打分。
6. 删除及迁移：抽样执行 revoke/erase/rebuild/backup restore，检查证据与错误边界。
7. 评审决策：逐项审议 A1–A6；全部满足再比较质量、成本、维护性。

## 7. 选型输出模板

- `Candidate`：版本 / Commit / Digest / 部署拓扑
- `Gate result`：A1—A6 单项 PASS / FAIL / NOT_RUN
- `Metrics`：指标、分母、置信区间或抽样误差说明
- `Known limitations`：不支持删除粒度 / 来源映射等
- `Decision`：selected / not selected / more evidence needed
- `Production conditions`：需额外补齐的测试、法务/安全签字

**默认结论：所有候选均为 NOT_SELECTED 直到试验与批准完成。**
