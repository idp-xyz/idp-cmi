# IDP-CMI Technical Design — 工程启动工作包（Handoff）V1.0

**性质：对下一步 Technical Design 的输入清单；并非已提交可运行的服务或完整 DDL**。

## 0. 开发冻结原则

1. **不能越过 ADR 的状态**：ADR Proposed 阶段可搭建沙箱和接口草图，但实际交付的外部商用版本需完成许可及安全会签。
2. **先无引擎可运行，再接引擎**：最小成功标准是 PostgreSQL 上的 Source/Memory/Bundle 读写、FTS、安全检查、撤权屏蔽及上下文预算。
3. **不抢 EER/ HOST 责任**：EER/Host 不需要 CMI 才能启动；CMI 不生成业务写命令。

## 1. 首批工程任务依赖图

```mermaid
flowchart LR
  ADR[ADR批准] --> SCHEMA[Schema review]
  SCHEMA --> DB[PostgreSQL migration + RLS]
  DB --> API[CMI REST API]
  API --> LIFE[Lifecycle & Erasure]
  LIFE --> OUT[Outbox and projections]
  OUT --> RET[FTS/pgvector Search]
  RET --> CMP[Context Compiler]
  CMP --> BASE[S0 Acceptance]
  BASE --> POC[Hindsight / Mem0 adapters]
  POC --> INT[HOST / EER / Parcel integration]
```

## 2. 自有代码建议目录（拟定）

```
idp-cmi/
  api/                      # transport, openapi, authn boundary
  domain/source/            # SourceRecord aggregates
  domain/memory/            # MemoryRecord aggregate, lifecycle, CAS
  domain/context/           # ContextBundle/compiler/manifest
  policy/                   # authz, purpose, classification, tenancy
  storage/postgres/         # migrations, RLS, repositories
  projections/              # fts, pgvector, outbox worker/checkpoints
  engines/spi/              # memory engine plugin contract
  engines/hindsight/        # PoC only until Gate approved
  engines/mem0/             # PoC only until Gate approved
  adapters/mcp/             # only MCP 2026-07-28
  adapters/host/            # consumer examples, optional
  adapters/eer/             # authorized event/evidence references, optional
  tests/                    # contract/security/migration/load/poc
  docs/                     # ADR, Technical Design, RFC
```

## 3. Database schema 的下一步严谨决策

- canonical tables: `source_record`, `source_revision`, `memory_record`, `memory_revision`, `memory_source_link`, `context_bundle`, `context_bundle_item`, `policy_binding`, `erasure_operation`, `erasure_tombstone`, `outbox_event`, `projection_generation`, `projection_checkpoint`, `engine_mapping`, `audit_event_ref`。
- 所有业务记录必须含 `tenant_id`，并建立 `principal/purpose/classification` 的授权边界；不可只依赖向量库上一个过滤条件。
- 源/记忆变更必须 append revision，更新 current pointer 时 CAS；outbox 在同一数据库事务提交。
- RLS 与连接池事务上下文隔离策略要有跨 tenant 自动化测试；不能让 DB admin 账号给常规 API 连接池使用。
- Erasure Tombstone 必须是不可恢复最小元数据；不得照搬历史 `MemoryRecord`。
- 对 LLM 输出、FTS 和向量投影建立可重建 `generation` 与 `embedding_model_version`，迁移期间不破坏 canonical 数据。

## 4. 前六个工程 PR（顺序建议）

| PR | 工件 | 关键测试 |
|---|---|---|
| PR-01 | Repository bootstrap + API error model + authn middleware | 无 HOST/EER 启动与健康检查 |
| PR-02 | PostgreSQL migrations + RLS + SourceRecord CRUD | tenant/purpose 不泄漏；自然键幂等 |
| PR-03 | MemoryRevision + transition + CAS + source dependency | 双并发 412；撤权后 read deny |
| PR-04 | Outbox + FTS + pgvector index/checkpoint | 乱序重放幂等；旧 index 不返现 |
| PR-05 | ContextCompiler + Bundle Manifest + budget validation | token 限额；source/ref/版本复现 |
| PR-06 | EngineSPI + Hindsight/ Mem0 PoC harness | 引擎断开 fallback；删除/rebuild/映射 Gate |

## 5. 必须等待的外部输入

- EER 真实 event/evidence API schema、鉴权方式；在未经联调前不臆造字段。
- HOST 实际 Context API 消费模式与已使用的 tokenizer/model profile。
- Parcel 最小脱敏场景、客户数据授权、业务 SoR 查询接口。
- 企业 IAM/PDP 的实际选择、KMS/对象存储/密钥管理、驻留区域与删除 SLA。
- 商业化许可/自托管方式及支持的 SDK release 锁定策略。

## 6. 开发验收顺序

`Core Spec G0–G6` → `ADR PoC Gate A1–A6` → `Parcel G7` → `生产威胁建模/HA/恢复与负载 SLO`。在任一安全 Gate 失败时，不得通过“先不管权限、将来补”方式签收。
