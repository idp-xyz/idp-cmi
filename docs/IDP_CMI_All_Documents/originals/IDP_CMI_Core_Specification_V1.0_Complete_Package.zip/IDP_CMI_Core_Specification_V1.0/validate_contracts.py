"""IDP-CMI contract static validation — schema structure, positive/negative examples and API input trust boundary."""
from pathlib import Path
import json
import yaml
from jsonschema import Draft202012Validator, FormatChecker

base=Path(__file__).resolve().parent
names=["source-record","memory-record","context-bundle","lifecycle-transition","authorization-context","erasure-tombstone"]
for name in names:
    schema=json.loads((base/"schemas"/(name+".schema.json")).read_text(encoding="utf-8"))
    example=json.loads((base/"examples"/(name+".json")).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema,format_checker=FormatChecker()).validate(example)
    print("PASS positive contract:",name)

for name,mutation in [
    ('memory-record', {'status': 'erased'}),
    ('memory-record', {'tenant_id': ''}),
    ('memory-record', {'confidence': 1.2}),
    ('source-record', {'status': 'erased'}),
    ('context-bundle', {'extra_rogue_property': True}),
    ('erasure-tombstone', {'claim_text': 'sensitive text must never appear in tombstone'}),
]:
    schema=json.loads((base/"schemas"/(name+".schema.json")).read_text(encoding="utf-8"))
    example=json.loads((base/"examples"/(name+".json")).read_text(encoding="utf-8"))
    example.update(mutation)
    assert not Draft202012Validator(schema,format_checker=FormatChecker()).is_valid(example), (name,mutation)
    print("PASS negative rejection:",name,mutation)

api=yaml.safe_load((base/'api.openapi.yaml').read_text(encoding='utf-8'))
assert api['openapi']=='3.1.0'
for path,method in [('/cmi/v1/sources/ingest','post'),('/cmi/v1/memories/propose','post')]:
    req=api['paths'][path][method]['requestBody']['content']['application/json']['schema']['$ref']
    obj=api['components']['schemas'][req.split('/')[-1]]
    assert obj['additionalProperties'] is False
    for server_owned in ('tenant_id','status','classification','source_trust','authority_scope','revision','memory_id','source_id'):
        assert server_owned not in obj['properties'],(path,server_owned)
print('PASS OpenAPI 3.1 trusted write-input boundaries')

ctx=json.loads((base/'examples/context-bundle.json').read_text(encoding='utf-8'))
assert sum(seg['token_count_estimated'] for seg in ctx['segments']) == ctx['budget']['selected_tokens_estimated']
assert ctx['budget']['selected_tokens_estimated'] + ctx['budget']['reserved_output_tokens'] <= ctx['budget']['hard_limit_tokens']
print('PASS sample ContextBundle semantic budget invariants')
print('ALL BASIC CONTRACT CHECKS PASSED')
