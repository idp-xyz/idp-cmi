# IDP-CMI Core Specification V1.0 · 交付清单

**状态**：Draft for Architecture Review（架构评审草案），并非已经部署、完成开发或经过性能实测的产品。

| 文件 | 用途 |
|---|---|
| `IDP_CMI_Core_Specification_V1.0.md` | 核心规格正文：责任边界、五项契约、数据语义、状态机、安全控制、API、一致性、验收与实施 |
| `IDP_CMI_Core_Specification_V1.0.html` | 单文件离线 HTML 阅读版，含目录检索、静态架构及生命周期图、打印/PDF |
| `schemas/{source-record,memory-record,context-bundle,lifecycle-transition,authorization-context}.schema.json` | 五个规范性核心 JSON Schema（Draft 2020-12） |
| `schemas/erasure-tombstone.schema.json` | 擦除终态的附加 Schema，不含已删除的来源正文或可恢复引用 |
| `examples/*.json` | 六份完全合成、结构验证通过的演示数据 |
| `api.openapi.yaml` | OpenAPI 3.1 接口骨架；公开写接口单独定义输入白名单，尚未补全全部响应模型 |
| `tests/acceptance_matrix.csv` | G0-G7 最小 40 项验收测试 |
| `validate_contracts.py` | Schema 正反样例、OpenAPI 边界和 Bundle 示例预算的静态校验脚本 |

## 快速验证

```bash
python -m pip install jsonschema pyyaml
python validate_contracts.py
```

## 技术评审建议流程

1. 先确定系统责任边界、数据真值归属、CMI 无 HOST/EER 独立性。
2. 冻结 SourceRecord / MemoryRecord / ContextBundle / Lifecycle / TenantSecurity 语义。
3. 确定 Source retention、隐私擦除例外、租户与资源授权的真实来源。
4. 按实际开发框架补齐请求/响应 OpenAPI、数据库迁移、审计与安全策略。
5. 通过 G0-G6 后再接入 Parcel 业务并在 G7 对照测试收益。

**适用限制**：本包是规格和示例，不包含运行中的服务器、数据库 migration、完整测试执行器或生产安全认证。样例中的 URL/ID/租户均为演示占位。
