#!/usr/bin/env python3
from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont
p=Path(__file__).resolve().parent
text=(p/'CMI_Whitepaper_V1.0.md').read_text(encoding='utf-8')+(p/'build_whitepaper.mjs').read_text(encoding='utf-8')
f=TTFont(p.parent/'assets/DroidSansFallback.ttf')
opts=subset.Options();opts.hinting=False;opts.recalc_timestamp=False
sub=subset.Subsetter(options=opts);sub.populate(text=text);sub.subset(f)
f.flavor='woff';f.save(p/'whitepaper_cjk_subset.woff')
print('Whitepaper font subset updated.')
