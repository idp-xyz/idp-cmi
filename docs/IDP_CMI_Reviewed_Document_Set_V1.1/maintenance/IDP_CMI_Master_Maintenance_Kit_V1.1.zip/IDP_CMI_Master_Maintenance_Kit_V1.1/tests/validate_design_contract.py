#!/usr/bin/env python3
"""Structural and illustrative negative checks; not an OpenAPI conformance suite or live API test."""
from pathlib import Path
import re,yaml
root=Path(__file__).resolve().parents[1]
d=yaml.safe_load((root/'engineering/CMI_Design_API_V1.1_draft.openapi.yaml').read_text())
assert d['openapi']=='3.1.0' and d['info']['version'].endswith('-draft')
expected={
 '/cmi/v1/sources/ingest':'post','/cmi/v1/memories/propose':'post','/cmi/v1/memories/search':'post',
 '/cmi/v1/memories/{memory_id}':'get','/cmi/v1/memories/{memory_id}/transitions':'post',
 '/cmi/v1/contexts/compile':'post','/cmi/v1/contexts/{bundle_id}':'get','/cmi/v1/contexts/{bundle_id}/validate':'post',
 '/cmi/v1/privacy/erasure-requests':'post','/cmi/v1/operations/{operation_id}':'get','/cmi/v1/health/live':'get','/cmi/v1/health/ready':'get'}
assert set(d['paths'])==set(expected)
for p,m in expected.items():
 assert m in d['paths'][p]; op=d['paths'][p][m]; assert op.get('operationId') and op.get('responses')
 required_path=set(re.findall(r'\{([^{}]+)\}',p))
 actual_path={x['name'] for x in op.get('parameters',[]) if x['in']=='path' and x.get('required')}
 assert required_path==actual_path,(p,required_path,actual_path)
 assert op.get('x-cmi-evidence')
 if m=='post' and p not in ['/cmi/v1/memories/search','/cmi/v1/contexts/{bundle_id}/validate']:
  assert any(x.get('name')=='Idempotency-Key' and x.get('required') for x in op.get('parameters',[])),p

def resolve(pointer):
 assert pointer.startswith('#/')
 node=d
 for component in pointer[2:].split('/'):node=node[component.replace('~1','/').replace('~0','~')]
 return node
def walk(x):
 if isinstance(x,dict):
  if '$ref' in x:resolve(x['$ref'])
  for y in x.values():walk(y)
 elif isinstance(x,list):
  for y in x:walk(y)
walk(d)
assert set(d['components']['schemas']['Scope']['properties']['type']['enum'])=={'tenant','organization','team','project','user','business_object'}
assert set(d['components']['schemas']['MemoryRecord']['properties']['status']['enum'])=={'candidate','quarantined','active','disputed','superseded','expired','revoked'}
assert d['components']['schemas']['CompileRequest']['properties']['scopes']['type']=='array'
assert d['components']['schemas']['MemorySearchRequest']['properties']['scopes']['type']=='array'
assert d['security']==[{'bearerAuth':[]}]
assert d['paths']['/cmi/v1/health/live']['get']['security']==[]
assert '412' in d['paths']['/cmi/v1/memories/{memory_id}/transitions']['post']['responses']
assert '202' in d['paths']['/cmi/v1/privacy/erasure-requests']['post']['responses']

def valid(schema,value):
 if '$ref' in schema:return valid(resolve(schema['$ref']),value)
 if 'anyOf' in schema and not any(valid(sub,value) for sub in schema['anyOf']):return False
 typ=schema.get('type'); types=typ if isinstance(typ,list) else [typ]
 if typ is not None:
  checks={'object':lambda x:isinstance(x,dict),'array':lambda x:isinstance(x,list),'string':lambda x:isinstance(x,str),'integer':lambda x:isinstance(x,int) and not isinstance(x,bool),'number':lambda x:isinstance(x,(int,float)) and not isinstance(x,bool),'boolean':lambda x:isinstance(x,bool),'null':lambda x:x is None}
  if not any(checks[t](value) for t in types):return False
 if 'enum' in schema and value not in schema['enum']:return False
 if 'const' in schema and value!=schema['const']:return False
 if isinstance(value,str) and len(value)<schema.get('minLength',0):return False
 if isinstance(value,(int,float)) and not isinstance(value,bool):
  if 'minimum' in schema and value<schema['minimum']:return False
  if 'maximum' in schema and value>schema['maximum']:return False
 if isinstance(value,list):
  if len(value)<schema.get('minItems',0):return False
  if not all(valid(schema.get('items',{}),v) for v in value):return False
 if isinstance(value,dict):
  if any(k not in value for k in schema.get('required',[])):return False
  props=schema.get('properties',{})
  if schema.get('additionalProperties') is False and any(k not in props for k in value):return False
  if any(not valid(props[k],v) for k,v in value.items() if k in props):return False
 return True
schemas=d['components']['schemas'];scopes=[{'type':'user','id':'alice'},{'type':'team','id':'logistics'}]
compile={'task_ref':'task-1','query':'prepare report','scopes':scopes,'purpose':'work','model_profile_ref':'model-1','budget':{'hard_limit_tokens':4000,'reserved_system_tokens':500,'reserved_output_tokens':500}}
assert valid(schemas['CompileRequest'],compile)
assert not valid(schemas['CompileRequest'],dict(compile,scopes=[]))
assert not valid(schemas['CompileRequest'],dict(compile,tenant_id='attacker'))
assert not valid(schemas['CompileRequest'],dict(compile,principal='self-claimed'))
assert not valid(schemas['CompileRequest'],dict(compile,budget={'hard_limit_tokens':0,'reserved_system_tokens':0,'reserved_output_tokens':0}))
proposal={'scope':scopes[0],'kind':'preference','claim_text':'先给结论','source_refs':[{'source_id':'src-1','source_revision':'etag-abc'}],'purpose':'work'}
assert valid(schemas['MemoryProposalRequest'],proposal)
assert not valid(schemas['MemoryProposalRequest'],dict(proposal,source_refs=[]))
assert not valid(schemas['MemoryProposalRequest'],dict(proposal,status='active'))
assert not valid(schemas['MemoryProposalRequest'],dict(proposal,authority_scope='all'))
assert not valid(schemas['TransitionRequest'],{'expected_revision':0,'target_status':'active','reason_code':'x'})
assert not valid(schemas['TransitionRequest'],{'expected_revision':1,'target_status':'erased','reason_code':'x'})
print('PASS: 12 paths, internal refs, path parameters, 23 schemas, six scopes, seven states, idempotency headers and illustrative positive/negative payloads.')
print('LIMIT: structural/subset checks only; not OpenAPI official validator, security audit, runtime or PostgreSQL test.')
