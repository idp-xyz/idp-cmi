#!/usr/bin/env python3
"""Cross-document invariant checks. Complements human review; does not prove production behavior."""
from pathlib import Path
import yaml
r=Path(__file__).resolve().parents[1]
w=(r/'whitepaper/CMI_Whitepaper_V1.0.md').read_text(encoding='utf-8')
m=(r/'CMI_Master.md').read_text(encoding='utf-8')
a=yaml.safe_load((r/'engineering/CMI_Design_API_V1.1_draft.openapi.yaml').read_text(encoding='utf-8'))
checks={
 '独立边界':(('独立','HOST','EER','MCP'),('独立','HOST','EER','MCP')),
 '协议基线':(('2026-07-28',),('2026-07-28',)),
 '六个作用范围':(('tenant','organization','team','project','user','business_object'),('tenant','organization','team','project','user','business_object')),
 '七个生命周期状态':(('candidate','quarantined','active','disputed','superseded','expired','revoked'),('candidate','quarantined','active','disputed','superseded','expired','revoked')),
 '必要及替代来源权限':(('必要来源','替代依据'),('必要来源','替代来源')),
 '来源引用不证明真实性':(('不能证明来源真实',),('不能证明对象',)),
 '模型推断与事实分离':(('模型输出','候选'),('模型','候选')),
 '撤权与物理擦除区分':(('撤权','物理删除'),('撤权','物理擦除')),
 '预算与标注遗漏':(('预算','遗漏'),('预算','预算不足')),
 '历史原型与目标区分':(('历史报告','当前原型'),('历史快照','目标设计')),
 '现行与历史材料区分':(('核心规格','技术设计'),('历史材料','技术设计')),
 '历史测试不等于实测':(('25 项通过','本次新跑'),('25 项测试通过','本次重新运行')),
}
for name,(wa,ma) in checks.items():
 for token in wa:
  assert token in w,(name,'whitepaper',token)
 for token in ma:
  assert token in m,(name,'master',token)
assert a['info']['version']=='1.1.0-draft'
assert a['components']['schemas']['CompileRequest']['properties']['scopes']['type']=='array'
assert a['components']['schemas']['MemorySearchRequest']['properties']['scopes']['type']=='array'
assert '201' in a['paths']['/cmi/v1/contexts/compile']['post']['responses']
assert '202' in a['paths']['/cmi/v1/privacy/erasure-requests']['post']['responses']
assert '412' in a['paths']['/cmi/v1/memories/{memory_id}/transitions']['post']['responses']
print(f'PASS: {len(checks)} cross-document invariant groups and 5 target-contract checks.')
print('LIMIT: text/structural checks do not prove semantic completeness, implementation, or deployment.')
