#!/usr/bin/env python3
"""Generate the explicitly proposed CMI API contract, not a statement of implementation."""
from pathlib import Path
import copy,yaml
ROOT=Path(__file__).resolve().parents[1]
def ref(name): return {'$ref':f'#/components/schemas/{name}'}
def obj(properties, required=(), description=''):
 x={'type':'object','additionalProperties':False,'properties':properties}
 if required:x['required']=list(required)
 if description:x['description']=description
 return x
def arr(item, *, minItems=None, description=None):
 x={'type':'array','items':item}
 if minItems is not None:x['minItems']=minItems
 if description:x['description']=description
 return x
s={'type':'string','minLength':1}; dt={'type':'string','format':'date-time'}; nonneg={'type':'integer','minimum':0}; positive={'type':'integer','minimum':1}
nullable_dt={'type':['string','null'],'format':'date-time'}
source_revision={'anyOf':[positive,s], 'description':'来源版本可以是内部数字修订或上游不透明版本标识；以已审定的接入契约为准。'}
scope_types=['tenant','organization','team','project','user','business_object']
statuses=['candidate','quarantined','active','disputed','superseded','expired','revoked']
schemas={}
schemas['Scope']=obj({'type':{'type':'string','enum':scope_types},'id':s},['type','id'],'归属或请求范围；不是身份，也不自行授予访问权限。')
schemas['SourceRef']=obj({'source_id':s,'source_revision':source_revision,'locator':{'type':['string','null']}},['source_id','source_revision'],'仅为来源版本引用，使用前须验证当前授权与有效性。')
schemas['MemoryRef']=obj({'memory_id':s,'revision':positive},['memory_id','revision'])
schemas['SupportSet']=obj({'all_sources':arr(ref('SourceRef'),minItems=1)},['all_sources'],'一组对该陈述均属必要的来源。不同支持组只有在被验证为各自独立充分时才构成替代依据。')
schemas['SourceIngestRequest']=obj({'source_system':s,'source_object_key':s,'source_revision':source_revision,'source_type':{'type':'string','enum':['event','document','conversation','api_snapshot','human_attestation']},'content_location':s,'content_hash':s,'captured_at':dt,'client_request_ref':s},['source_system','source_object_key','source_revision','source_type','content_location'],'调用方提交的定位和摘要均为待验证输入，不证明对象、权限和内容真实。')
schemas['SourceIngestResult']=obj({'source_id':s,'source_revision':source_revision,'status':{'type':'string','enum':['pending_verification','available','restricted','revoked']},'operation_id':s},['source_id','source_revision','status'])
schemas['MemoryProposalRequest']=obj({'scope':ref('Scope'),'subject_ref':s,'kind':{'type':'string','enum':['working','episodic','semantic','procedural','preference']},'claim_text':s,'language':s,'source_refs':arr(ref('SourceRef'),minItems=1),'valid_from':nullable_dt,'valid_to':nullable_dt,'purpose':s},['scope','kind','claim_text','source_refs','purpose'],'仅提交候选；不得由调用方自行确权、声明权威、激活或绕过审批。kind 为提案，最终映射待审定。')
schemas['MemoryProposalResult']=obj({'memory_id':s,'revision':positive,'status':{'type':'string','const':'candidate'}},['memory_id','revision','status'])
schemas['MemoryRecord']=obj({'memory_id':s,'tenant_id':s,'revision':positive,'scope':ref('Scope'),'subject_ref':{'type':['string','null']},'kind':s,'assertion_kind':s,'claim_text':s,'language':s,'status':{'type':'string','enum':statuses},'support_sets':arr(ref('SupportSet'),minItems=1),'valid_from':nullable_dt,'valid_to':nullable_dt,'recorded_at':dt,'classification':s,'authority_scope':{'type':['string','null']},'confidence':{'type':['number','null'],'minimum':0,'maximum':1}},['memory_id','tenant_id','revision','scope','kind','assertion_kind','claim_text','status','support_sets','recorded_at','classification'],'目标读模型，不代表历史原型的精简响应；confidence 不等于事实权威性。')
schemas['MemorySearchRequest']=obj({'query':s,'scopes':arr(ref('Scope'),minItems=1,description='目标多范围查询；范围由服务端授权收窄，不应依赖客户端声明。'),'purpose':s,'limit':positive,'as_of_valid':nullable_dt,'known_at':nullable_dt,'required_projection_tickets':arr(s)},['query','scopes','purpose'])
schemas['MemorySearchResult']=obj({'items':arr(ref('MemoryRecord')),'warnings':arr(s),'projection_state':{'type':'string','enum':['current','pending','unknown']}},['items','warnings'],'返回之前复验权限、版本、来源、状态和时效；结果不得包含无权访问的内容。')
schemas['TransitionRequest']=obj({'expected_revision':positive,'target_status':{'type':'string','enum':statuses},'reason_code':s,'evidence_refs':arr(s),'approval_ref':{'type':['string','null']}},['expected_revision','target_status','reason_code'],'CAS 更新并核验真实审批；approval_ref 非空不构成审批证明。合法转移见主文档。')
schemas['TransitionResult']=obj({'memory_id':s,'revision':positive,'status':{'type':'string','enum':statuses}},['memory_id','revision','status'])
schemas['TokenBudget']=obj({'hard_limit_tokens':positive,'reserved_system_tokens':nonneg,'reserved_output_tokens':nonneg,'fixed_overhead_tokens':nonneg},['hard_limit_tokens','reserved_system_tokens','reserved_output_tokens'],'可用预算 = 上限减系统、输出和固定开销；必要信息放不下时显式失败。')
schemas['CompileRequest']=obj({'task_ref':s,'query':s,'scopes':arr(ref('Scope'),minItems=1),'purpose':s,'model_profile_ref':s,'budget':ref('TokenBudget'),'as_of_valid':nullable_dt,'known_at':nullable_dt,'required_projection_tickets':arr(s)},['task_ref','query','scopes','purpose','model_profile_ref','budget'],'多范围是目标设计；所核对的历史原型只支持单范围搜索且没有该接口。')
schemas['BundleSegment']=obj({'segment_id':s,'kind':s,'content':s,'memory_refs':arr(ref('MemoryRef')),'support_sets':arr(ref('SupportSet')),'token_count':nonneg,'exact_token_count':{'type':'boolean'},'requires_live_revalidation':{'type':'boolean'}},['segment_id','kind','content','memory_refs','support_sets','token_count','exact_token_count','requires_live_revalidation'])
schemas['ContextBundle']=obj({'bundle_id':s,'tenant_id':s,'principal_ref':s,'purpose':s,'compiled_at':dt,'expires_at':dt,'policy_version':s,'model_profile_ref':s,'segments':arr(ref('BundleSegment')),'manifest_hash':s,'warnings':arr(s)},['bundle_id','tenant_id','principal_ref','purpose','compiled_at','expires_at','policy_version','model_profile_ref','segments','manifest_hash','warnings'],'仅表示编译输出；清单哈希不证明调用方实际向模型发送了这些内容。')
schemas['BundleValidateRequest']=obj({'task_ref':s,'purpose':s},['task_ref','purpose'])
schemas['BundleValidateResult']=obj({'valid':{'type':'boolean'},'reason_codes':arr(s),'checked_at':dt},['valid','reason_codes','checked_at'],'按当前身份、目的、策略、来源、记忆状态、版本和到期条件复验。')
schemas['ErasureRequest']=obj({'target_type':{'type':'string','enum':['source','memory','bundle']},'target_id':s,'reason_code':s,'approval_ref':{'type':['string','null']}},['target_type','target_id','reason_code'],'202 仅表示请求受理；受理、可见性阻断、各域清理、备份处置和验证是不同阶段。')
schemas['Operation']=obj({'operation_id':s,'status':{'type':'string','enum':['accepted','blocked','in_progress','partial','retryable_failure','exception','verified']},'updated_at':dt,'warnings':arr(s)},['operation_id','status','updated_at','warnings'])
schemas['Error']=obj({'error':obj({'code':s,'message':s,'request_id':s,'retryable':{'type':'boolean'}},['code','message','request_id','retryable'])},['error'])
schemas['Health']=obj({'status':s},['status'])
idempotency={'name':'Idempotency-Key','in':'header','required':True,'schema':s,'description':'与服务端可信租户、主体和操作绑定；同键不同请求应冲突。'}
def responses(code, schema, extra=()):
 out={str(code):{'description':'CMI 操作结果，不代表外部业务执行完成','content':{'application/json':{'schema':ref(schema)}}}}
 for c in extra:out[str(c)]={'description':'已受理的异步操作','content':{'application/json':{'schema':ref('Operation')}}}
 for c,label in [(400,'输入不符合契约'),(401,'身份未验证'),(403,'访问未授权'),(404,'资源不存在或为防枚举隐藏'),(409,'幂等、不可变版本或投影冲突'),(422,'策略、预算或语义校验失败'),(429,'请求受限'),(503,'依赖不可用，受保护数据默认拒绝')]:
  out[str(c)]={'description':label,'content':{'application/json':{'schema':ref('Error')}}}
 return out
def operation(opid,summary,code,result,request=None,*,write=False,history=False,path_param=None,extra=()):
 x={'operationId':opid,'summary':summary,'x-cmi-evidence':'历史原型路径存在；字段、权限与生产可用性另需核验' if history else '目标设计；历史原型未实现','responses':responses(code,result,extra)}
 params=[]
 if path_param:params.append({'name':path_param,'in':'path','required':True,'schema':s})
 if write:params.append(copy.deepcopy(idempotency))
 if params:x['parameters']=params
 if request:x['requestBody']={'required':True,'content':{'application/json':{'schema':ref(request)}}}
 return x
paths={}
def add(path,method,**kw):paths.setdefault(path,{})[method]=operation(**kw)
add('/cmi/v1/sources/ingest','post',opid='ingestSource',summary='登记并验证来源',code=201,result='SourceIngestResult',request='SourceIngestRequest',write=True,history=True,extra=(202,))
add('/cmi/v1/memories/propose','post',opid='proposeMemory',summary='提出候选记忆',code=201,result='MemoryProposalResult',request='MemoryProposalRequest',write=True,history=True)
add('/cmi/v1/memories/search','post',opid='searchMemories',summary='在获授权范围检索',code=200,result='MemorySearchResult',request='MemorySearchRequest',history=True)
add('/cmi/v1/memories/{memory_id}','get',opid='getMemory',summary='获取当前有权访问的记忆',code=200,result='MemoryRecord',path_param='memory_id',history=True)
add('/cmi/v1/memories/{memory_id}/transitions','post',opid='transitionMemory',summary='以预期版本转换生命周期',code=200,result='TransitionResult',request='TransitionRequest',write=True,path_param='memory_id',history=True)
paths['/cmi/v1/memories/{memory_id}/transitions']['post']['responses']['412']={'description':'预期修订版本不匹配','content':{'application/json':{'schema':ref('Error')}}}
add('/cmi/v1/contexts/compile','post',opid='compileContext',summary='编译获授权的多范围上下文',code=201,result='ContextBundle',request='CompileRequest',write=True)
add('/cmi/v1/contexts/{bundle_id}','get',opid='getContextBundle',summary='按当前授权读取上下文包',code=200,result='ContextBundle',path_param='bundle_id')
add('/cmi/v1/contexts/{bundle_id}/validate','post',opid='validateContextBundle',summary='在使用前复核上下文包',code=200,result='BundleValidateResult',request='BundleValidateRequest',path_param='bundle_id')
add('/cmi/v1/privacy/erasure-requests','post',opid='requestErasure',summary='受理擦除请求并跟踪状态',code=202,result='Operation',request='ErasureRequest',write=True)
add('/cmi/v1/operations/{operation_id}','get',opid='getOperation',summary='查询异步操作状态',code=200,result='Operation',path_param='operation_id')
add('/cmi/v1/health/live','get',opid='healthLive',summary='存活探针',code=200,result='Health',history=True)
add('/cmi/v1/health/ready','get',opid='healthReady',summary='就绪探针',code=200,result='Health',history=True)
for p in ['/cmi/v1/health/live','/cmi/v1/health/ready']:
 paths[p]['get']['security']=[]
 paths[p]['get']['description']='探针认证及暴露范围由部署策略另行限制；不得泄露敏感配置。'
doc={'openapi':'3.1.0','info':{'title':'IDP CMI Proposed Design API','version':'1.1.0-draft','description':'目标设计契约草案，与白皮书 V1.0 对齐；未经工程、身份安全及兼容性评审，未发布为生产 API。历史原型可能具有同名路径但请求/响应不同。'},'servers':[{'url':'https://cmi.example.invalid','description':'非真实服务地址'}],'security':[{'bearerAuth':[]}], 'paths':paths,'components':{'securitySchemes':{'bearerAuth':{'type':'http','scheme':'bearer','description':'令牌须由受信身份组件校验；生产凭据类型与策略以实际部署为准。'}},'schemas':schemas},'x-cmi-invariants':['身份、租户、范围和来源权限由服务端校验，策略不可判断则拒绝受保护数据。','授权和时效是硬约束，排序不得抵消；必要来源全部授权，替代来源必须独立充分。','归档、撤权、逻辑阻断和物理擦除是不同状态。','投影票据为指定写入与代际的凭证，不宣称全局提交序。','CMI 与 HOST、EER、MCP Infrastructure 无硬依赖；业务实时事实以权威源为准。']}
out=ROOT/'engineering'/'CMI_Design_API_V1.1_draft.openapi.yaml'
out.write_text(yaml.safe_dump(doc,sort_keys=False,allow_unicode=True,width=1000),encoding='utf-8')
print(f'{out}: {len(paths)} paths, {len(schemas)} schemas')
