# IDP CMI 统一文档与工程契约维护包 V1.1

当前白皮书为 V1.0，统一技术入口为 V1.1 审阅稿。历史资料单独归档。除明确引用历史结果外，不能将设计草案写成已实现或已验收。

## 文档生成

需要 Node.js 18 或以上；包含 Marked 17.0.5，无需联网安装 JavaScript 依赖。

```bash
node build.mjs
node whitepaper/build_whitepaper.mjs
```

分别生成统一入口和白皮书。`CMI_Master.md` 与 `whitepaper/CMI_Whitepaper_V1.0.md` 各为对应文档的唯一正文；修改后共同核对产品边界、生命周期、授权、接口状态和验证证据。不要单独手工维护生成的 HTML。

新增字符时可在安装 Python 3 与 FontTools 的环境运行 `python3 update_font.py` 重新生成统一入口字体子集，再执行构建。白皮书有新增字符时运行 `python3 whitepaper/update_whitepaper_font.py`；其他设备会回退至系统字体。字体原始文件及 Apache 2.0 许可在 `assets/`；Marked 许可在 `vendor/marked/`。

## 目标 API

`engineering/CMI_Design_API_V1.1_draft.openapi.yaml` 是目标设计草案，并非当前部署的接口承诺。修改 `source/build_contract.py`，然后运行：

```bash
python3 source/build_contract.py
python3 tests/validate_design_contract.py
```

需要 Python 3 与 PyYAML。测试覆盖结构、引用、路径参数、状态集合和示例载荷的一部分；不等于完整 OpenAPI 标准验证、安全审计、实时 API 或数据库测试。正式发布前须由工程、安全和接口负责人评审，与实际版本和验收证据绑定。

## 维护规则

- 产品方向依据经批准的设计；真实实现依据标识明确的代码版本和部署；验收依据同版本测试证据；业务当前事实由权威系统提供。
- 白皮书、统一入口和接口草案的共通约束需要在同一次变更中复核，任何新选型或未经批准的决定应清楚标识。
- 历史原始文档和历史原型保留在单独归档；此包不把历史 Schema 当作现行契约。
